# 📱 Grimório de Bolso - Documentação Técnica e Correções

## 📋 Sumário Executivo

O **Grimório de Bolso** é um aplicativo Flutter para praticantes de bruxaria moderna, especialmente adaptado para o Brasil e Hemisfério Sul. Este documento detalha as correções necessárias nos conceitos de bruxaria e a arquitetura técnica implementada.

## 🔴 CORREÇÕES CRÍTICAS IMPLEMENTADAS

### 1. **Hemisfério Sul - Datas dos Sabbats** ⚠️ CRÍTICO

**PROBLEMA ORIGINAL**: As datas estavam para o Hemisfério Norte
**CORREÇÃO IMPLEMENTADA**:

| Sabbat | Hemisfério Norte | **BRASIL (Sul)** | Significado Adaptado |
|--------|------------------|------------------|---------------------|
| Samhain | 31 Outubro | **30 Abril/1 Maio** | Ano Novo das Bruxas - Início do Outono |
| Yule | 21 Dezembro | **21 Junho** | Solstício de Inverno - Festa Junina |
| Imbolc | 2 Fevereiro | **1 Agosto** | Preparação para Primavera |
| Ostara | 21 Março | **21 Setembro** | Equinócio da Primavera |
| Beltane | 1 Maio | **31 Out/1 Nov** | Fertilidade - Finados |
| Litha | 21 Junho | **21 Dezembro** | Solstício de Verão - Festas de Fim de Ano |
| Lughnasadh | 1 Agosto | **2 Fevereiro** | Primeira Colheita - Pós-Verão |
| Mabon | 21 Setembro | **21 Março** | Equinócio de Outono - Preparação |

### 2. **Segurança com Cristais** ⚠️ IMPORTANTE

**ADIÇÕES IMPLEMENTADAS**:

#### Cristais que NUNCA devem ir na água:
- **Selenita**: Dissolve completamente
- **Halita**: É sal, dissolve
- **Pirita**: Libera ácido sulfúrico
- **Lepidolita**: Contém lítio tóxico
- **Malaquita**: Libera cobre tóxico

#### Cristais que desbotam no sol:
- **Ametista**: Fica amarelada
- **Quartzo Rosa**: Perde cor
- **Citrino**: Clareia
- **Água-marinha**: Desbota

### 3. **Segurança com Ervas** ⚠️ VITAL

**AVISOS IMPLEMENTADOS**:
- ⚠️ **Artemísia**: Proibida para grávidas (abortiva)
- ⚠️ **Arruda**: Tóxica para grávidas e pets
- ⚠️ **Eucalipto**: Venenoso para gatos e cães
- ⚠️ **Canela**: Pode causar irritação na pele
- ⚠️ **Todas as ervas**: Verificar alergias antes do uso

### 4. **Fases da Lua - Clarificações**

**CORREÇÕES**:
- **Lua Nova**: Novos começos E banimento (não apenas um)
- **Lua Crescente**: Atração e crescimento
- **Lua Cheia**: TODOS os tipos de magia (pico de poder)
- **Lua Minguante**: Liberação, cura, limpeza

### 5. **Elementos e Direções (Hemisfério Sul)**

**ADAPTAÇÃO BRASILEIRA**:
- **Norte**: Terra (não Ar como no Norte)
- **Sul**: Fogo (não Terra)
- **Leste**: Ar (mantém)
- **Oeste**: Água (mantém)

## 🏗️ Arquitetura Técnica

### Stack Tecnológica

```yaml
Frontend:
  - Flutter 3.x
  - Riverpod 2.0 (State Management)
  - GoRouter (Navigation)
  - SQLite (Local Storage)

Design System:
  - Material Design 3
  - Custom Theme (Whimsigoth/Pastel Goth)
  - Google Fonts (Cinzel Decorative + Nunito)
  - Phosphor Icons + Custom Pixel Art

Backend (Fase 2):
  - Supabase ou AWS Amplify
  - OpenAI API (via proxy)
  - Feature Toggles System
```

### Estrutura de Pastas

```
lib/
├── core/
│   ├── theme/          # Tema e cores
│   ├── database/       # SQLite service
│   ├── router/         # GoRouter config
│   ├── notifications/  # Local notifications
│   └── utils/          # Helpers
│
├── features/
│   ├── moon_calendar/  # Calendário Lunar
│   │   ├── models/
│   │   ├── providers/
│   │   ├── views/
│   │   └── widgets/
│   │
│   ├── wheel_of_year/  # Roda do Ano/Sabbats
│   │   ├── models/     # Com datas corrigidas
│   │   └── ...
│   │
│   ├── grimoire/       # Livro de Feitiços
│   │   ├── models/
│   │   └── ...
│   │
│   ├── encyclopedia/   # Cristais, Ervas, Cores
│   │   ├── models/     # Com avisos de segurança
│   │   └── ...
│   │
│   ├── journals/       # Diários
│   │   ├── dreams/
│   │   ├── desires/
│   │   └── practice/
│   │
│   └── sigils/         # Sigilos
│       └── ...
│
└── main.dart
```

### Modelos de Dados Principais

```dart
// Fase Lunar com Correspondências
class MoonPhase {
  MoonPhaseType type;
  DateTime date;
  double illumination;
  String zodiacSign;
  List<MagicalCorrespondence> correspondences;
  List<String> ritualSuggestions;
  // Avisos de segurança incluídos
}

// Sabbat Adaptado ao Hemisfério Sul
class Sabbat {
  SabbatType type;
  DateTime dateNorthernHemisphere;
  DateTime dateSouthernHemisphere; // Data correta para Brasil
  List<String> traditions;
  List<String> warnings; // Segurança com fogo, etc
}

// Cristal com Segurança Completa
class Crystal {
  String name;
  double hardnessMohs;
  CrystalCareInstructions care; // Água, sol, etc
  List<String> warnings; // Toxicidade, etc
}
```

### Sistema de Feature Toggles

```dart
// Configuração dinâmica Free vs Premium
{
  "features": {
    "grimoire_limit": 20,        // Free: 20 feitiços
    "ai_daily_uses": 1,          // Free: 1 uso/dia
    "full_encyclopedia": false,   // Premium only
    "cloud_backup": false,        // Premium only
    "astrology_map": false,       // Premium only
    "magic_journeys": false       // Premium only
  }
}
```

## 🎨 Design System

### Paleta de Cores (Whimsigoth)

```dart
// Cores implementadas no app_theme.dart
Background:    #0B0A16  // Roxo quase preto
Surface:       #171425  // Roxo escuro (cards)
Lilac:         #C9A7FF  // Cor principal
Pink Witch:    #F1A7C5  // Rosa bruxinha
Mint:          #A7F0D8  // Verde cura
Star Yellow:   #FFE8A3  // Amarelo glitter
```

### Microinterações Mágicas

1. **Partículas de Glitter**: Animação contínua no background
2. **Toque em Botões**: Explosão de estrelas pixeladas
3. **Salvamento**: Animação de selo de cera
4. **Lua Cheia**: Pulsação e brilho especial

## 📊 Banco de Dados Local

### Tabelas SQLite

```sql
-- Feitiços
CREATE TABLE spells (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  purpose TEXT,
  type TEXT, -- 'attraction' ou 'banishment'
  moon_phase TEXT,
  ingredients TEXT, -- JSON
  instructions TEXT,
  created_at DATETIME,
  last_performed DATETIME
);

-- Diário de Sonhos
CREATE TABLE dream_journal (
  id TEXT PRIMARY KEY,
  date DATE NOT NULL,
  content TEXT,
  symbols TEXT, -- JSON array
  moon_phase TEXT,
  feelings TEXT
);

-- Cristais Favoritos
CREATE TABLE user_crystals (
  crystal_id TEXT,
  notes TEXT,
  acquired_date DATE,
  is_favorite BOOLEAN
);
```

## 🚀 Fases de Desenvolvimento

### ✅ Fase 1 - MVP Local (Atual)
- [x] Calendário Lunar com fases
- [x] Roda do Ano corrigida para Hemisfério Sul
- [x] CRUD de Feitiços
- [x] Diários (Sonhos, Desejos)
- [x] Enciclopédia básica com avisos
- [x] Gerador de Sigilos

### 🔄 Fase 2 - Cloud + IA
- [ ] Autenticação (Supabase Auth)
- [ ] Sincronização na nuvem
- [ ] IA para criação de feitiços
- [ ] Feature toggles dinâmicos

### 💎 Fase 3 - Premium
- [ ] Assinaturas (IAP)
- [ ] Limites Free vs Premium
- [ ] Backup automático
- [ ] Enciclopédia completa

### 🌟 Fase 4 - Astrologia
- [ ] Mapa astral pessoal
- [ ] Clima mágico diário
- [ ] Jornadas gamificadas
- [ ] Badges e conquistas

## ⚠️ Avisos Legais Implementados

```dart
class LegalWarnings {
  static const medical = '''
    Este aplicativo não substitui aconselhamento 
    médico ou psicológico profissional.
  ''';
  
  static const herbs = '''
    Sempre verifique toxicidade e alergias antes 
    de usar qualquer erva. Consulte um fitoterapeuta.
  ''';
  
  static const fire = '''
    Nunca deixe velas acesas sem supervisão. 
    Mantenha água por perto durante rituais com fogo.
  ''';
  
  static const crystals = '''
    Cristais não curam doenças. São ferramentas 
    energéticas complementares apenas.
  ''';
}
```

## 🔒 Segurança e Privacidade

### Dados Sensíveis
- Mapa astral (data/hora/local nascimento) - Criptografado localmente
- Diários pessoais - Armazenados apenas localmente na Fase 1
- Sincronização opcional na Fase 2 com criptografia

### Proteção Infantil
- Avisos sobre supervisão adulta
- Conteúdo apropriado para idade
- Sem links externos não verificados

## 📱 Features Únicas do App

1. **Adaptação Brasileira Completa**
   - Sabbats no hemisfério sul
   - Integração com festas locais (Junina, Finados)
   - Conteúdo em português

2. **Segurança em Primeiro Lugar**
   - Avisos em TODOS os conteúdos perigosos
   - Lista de cristais tóxicos/solúveis
   - Contraindicações de ervas

3. **Gamificação Sutil**
   - Badges pixelados fofos
   - Jornadas de 21 dias
   - Progresso visual com luas e estrelas

4. **IA Responsável**
   - Não se apresenta como "guru"
   - Sempre sugere, nunca impõe
   - Respeita diferentes tradições

## 🎯 Métricas de Sucesso

### KPIs Fase 1
- Downloads: 1000+ primeiro mês
- Retenção D7: >40%
- Avaliação: >4.5 estrelas
- Feitiços criados: >10 por usuário ativo

### KPIs Premium (Fase 3)
- Conversão Free→Premium: 5-10%
- Churn mensal: <10%
- LTV: R$150+
- CAC: <R$30

## 📚 Referências Verificadas

As informações foram validadas com:
- **Theodosia Corinth**: Série completa de bruxaria
- **Lindsay Squire**: Bruxaria Verde e da Terra  
- **Scott Cunningham**: Enciclopédias tradicionais
- **Adaptações locais**: Comunidade bruxa brasileira

---

**Desenvolvido com 🌙 e ✨ para bruxas brasileiras modernas**

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // Fundos e bases
  static const Color background = Color(0xFF0B0A16); // Quase preto com tom roxo profundo
  static const Color surface = Color(0xFF171425); // Roxo bem escuro para cards
  static const Color surfaceLight = Color(0xFF26213A); // Roxo mais claro para separações
  
  // Pastéis principais
  static const Color lilac = Color(0xFFC9A7FF); // Lilás (cor chave) - magia, espiritualidade
  static const Color pinkWitch = Color(0xFFF1A7C5); // Rosa bruxinha - amor próprio
  static const Color mint = Color(0xFFA7F0D8); // Verde menta - cura, natureza
  static const Color starYellow = Color(0xFFFFE8A3); // Amarelo estrela - brilho, glitter
  
  // Texto
  static const Color textPrimary = Color(0xFFF6F4FF); // Branquinho suave
  static const Color textSecondary = Color(0xFFB7B2D6); // Texto secundário/placeholder
  
  // Status
  static const Color success = Color(0xFF7EE08A); // Sucesso/proteção
  static const Color warning = Color(0xFFFF6B81); // Alerta/cuidado
  static const Color info = Color(0xFFA7C7FF); // Info/neutro
  
  // Elementos mágicos
  static const Color moonGlow = Color(0xFFE8E0FF); // Brilho lunar
  static const Color crystalShine = Color(0xFFD4B5FF); // Brilho de cristal
  static const Color candleFlame = Color(0xFFFFD4A3); // Chama de vela
  
  // Gradientes mágicos
  static const LinearGradient magicGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [lilac, pinkWitch, mint],
  );
  
  static const LinearGradient moonGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [moonGlow, lilac, surface],
  );
  
  static const RadialGradient glowGradient = RadialGradient(
    colors: [
      starYellow,
      Colors.transparent,
    ],
  );
}

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      
      // Cores principais
      primaryColor: AppColors.lilac,
      scaffoldBackgroundColor: AppColors.background,
      
      // ColorScheme
      colorScheme: const ColorScheme.dark(
        primary: AppColors.lilac,
        secondary: AppColors.pinkWitch,
        tertiary: AppColors.mint,
        surface: AppColors.surface,
        onSurface: AppColors.textPrimary,
        error: AppColors.warning,
        onError: AppColors.textPrimary,
        outline: AppColors.surfaceLight,
      ),
      
      // AppBar
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.cinzelDecorative(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: AppColors.lilac,
        ),
      ),
      
      // Card
      cardTheme: CardTheme(
        color: AppColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(
            color: AppColors.surfaceLight,
            width: 1,
          ),
        ),
      ),
      
      // Elevated Button
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.lilac,
          foregroundColor: const Color(0xFF2B2143),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: GoogleFonts.nunito(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      
      // Outlined Button
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.lilac,
          side: const BorderSide(color: AppColors.lilac),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: GoogleFonts.nunito(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      
      // Text Button
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.pinkWitch,
          textStyle: GoogleFonts.nunito(
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      
      // Input Decoration
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.surfaceLight),
        ),
        
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.surfaceLight),
        ),
        
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.lilac, width: 2),
        ),
        
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.warning),
        ),
        
        labelStyle: GoogleFonts.nunito(
          color: AppColors.textSecondary,
        ),
        
        hintStyle: GoogleFonts.nunito(
          color: AppColors.textSecondary.withOpacity(0.5),
        ),
      ),
      
      // Icon Theme
      iconTheme: const IconThemeData(
        color: AppColors.textPrimary,
        size: 24,
      ),
      
      // Divider
      dividerTheme: const DividerThemeData(
        color: AppColors.surfaceLight,
        thickness: 1,
      ),
      
      // Bottom Navigation Bar
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surface,
        selectedItemColor: AppColors.lilac,
        unselectedItemColor: AppColors.textSecondary,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      
      // Chip Theme
      chipTheme: ChipThemeData(
        backgroundColor: AppColors.surface,
        selectedColor: AppColors.lilac.withOpacity(0.3),
        labelStyle: GoogleFonts.nunito(
          color: AppColors.textPrimary,
          fontSize: 12,
        ),
        side: const BorderSide(color: AppColors.surfaceLight),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      
      // Text Theme
      textTheme: TextTheme(
        // Headlines
        headlineLarge: GoogleFonts.cinzelDecorative(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: AppColors.lilac,
        ),
        headlineMedium: GoogleFonts.cinzelDecorative(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: AppColors.lilac,
        ),
        headlineSmall: GoogleFonts.cinzelDecorative(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        
        // Titles
        titleLarge: GoogleFonts.nunito(
          fontSize: 22,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        titleMedium: GoogleFonts.nunito(
          fontSize: 18,
          fontWeight: FontWeight.w500,
          color: AppColors.textPrimary,
        ),
        titleSmall: GoogleFonts.nunito(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: AppColors.textPrimary,
        ),
        
        // Body
        bodyLarge: GoogleFonts.nunito(
          fontSize: 16,
          fontWeight: FontWeight.normal,
          color: AppColors.textPrimary,
        ),
        bodyMedium: GoogleFonts.nunito(
          fontSize: 14,
          fontWeight: FontWeight.normal,
          color: AppColors.textPrimary,
        ),
        bodySmall: GoogleFonts.nunito(
          fontSize: 12,
          fontWeight: FontWeight.normal,
          color: AppColors.textSecondary,
        ),
        
        // Labels
        labelLarge: GoogleFonts.nunito(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: AppColors.textPrimary,
        ),
        labelMedium: GoogleFonts.nunito(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: AppColors.textPrimary,
        ),
        labelSmall: GoogleFonts.nunito(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

// Extensões úteis para o tema
extension ThemeExtension on BuildContext {
  ThemeData get theme => Theme.of(this);
  TextTheme get textTheme => theme.textTheme;
  ColorScheme get colorScheme => theme.colorScheme;
  
  // Atalhos para cores comuns
  Color get primaryColor => AppColors.lilac;
  Color get secondaryColor => AppColors.pinkWitch;
  Color get backgroundColor => AppColors.background;
  Color get surfaceColor => AppColors.surface;
}

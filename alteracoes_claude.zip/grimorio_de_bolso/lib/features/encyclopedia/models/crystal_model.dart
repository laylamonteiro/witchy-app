import 'package:freezed_annotation/freezed_annotation.dart';

part 'crystal_model.freezed.dart';
part 'crystal_model.g.dart';

enum CrystalElement {
  earth('Terra', '🌍'),
  water('Água', '💧'),
  fire('Fogo', '🔥'),
  air('Ar', '💨'),
  spirit('Espírito', '✨');

  final String name;
  final String emoji;
  
  const CrystalElement(this.name, this.emoji);
}

enum CrystalChakra {
  root('Raiz', 'Muladhara', Colors.red),
  sacral('Sacral', 'Svadhisthana', Colors.orange),
  solarPlexus('Plexo Solar', 'Manipura', Colors.yellow),
  heart('Coração', 'Anahata', Colors.green),
  throat('Garganta', 'Vishuddha', Colors.blue),
  thirdEye('Terceiro Olho', 'Ajna', Colors.indigo),
  crown('Coroa', 'Sahasrara', Colors.purple);

  final String portugueseName;
  final String sanskritName;
  final Color color;
  
  const CrystalChakra(this.portugueseName, this.sanskritName, this.color);
}

@freezed
class Crystal with _$Crystal {
  const factory Crystal({
    required String id,
    required String name,
    required String scientificName,
    required String composition,
    required String colorDescription,
    required double hardnessMohs,
    required String origin,
    required String description,
    required List<CrystalElement> elements,
    required List<CrystalChakra> chakras,
    required List<String> magicalProperties,
    required List<String> emotionalProperties,
    required List<String> physicalProperties, // Com aviso de não substituir medicina
    required CrystalCareInstructions care,
    required List<String> combinationsHarmonic,
    required List<String> combinationsAvoid,
    required List<String> warnings,
    required List<String> howToUse,
    required String zodiacSigns,
    required String planetaryCorrespondence,
    String? imageUrl,
    String? personalNotes,
    @Default(false) bool isFavorite,
  }) = _Crystal;

  factory Crystal.fromJson(Map<String, dynamic> json) => _$CrystalFromJson(json);
}

@freezed
class CrystalCareInstructions with _$CrystalCareInstructions {
  const factory CrystalCareInstructions({
    required List<CleansingMethod> cleansingMethods,
    required List<ChargingMethod> chargingMethods,
    required List<String> storageRecommendations,
  }) = _CrystalCareInstructions;

  factory CrystalCareInstructions.fromJson(Map<String, dynamic> json) =>
      _$CrystalCareInstructionsFromJson(json);
}

@freezed
class CleansingMethod with _$CleansingMethod {
  const factory CleansingMethod({
    required String method,
    required bool isSafe,
    String? warning,
    String? instructions,
  }) = _CleansingMethod;

  factory CleansingMethod.fromJson(Map<String, dynamic> json) =>
      _$CleansingMethodFromJson(json);
}

@freezed
class ChargingMethod with _$ChargingMethod {
  const factory ChargingMethod({
    required String method,
    required bool isSafe,
    String? warning,
    String? instructions,
    Duration? recommendedDuration,
  }) = _ChargingMethod;

  factory ChargingMethod.fromJson(Map<String, dynamic> json) =>
      _$ChargingMethodFromJson(json);
}

// Base de dados de cristais com informações verificadas
class CrystalDatabase {
  static List<Crystal> getAllCrystals() {
    return [
      // QUARTZO TRANSPARENTE
      Crystal(
        id: 'clear_quartz',
        name: 'Quartzo Transparente',
        scientificName: 'SiO₂ (Dióxido de Silício)',
        composition: 'Dióxido de silício cristalizado',
        colorDescription: 'Transparente a branco leitoso',
        hardnessMohs: 7.0,
        origin: 'Brasil, Madagascar, Arkansas (EUA)',
        description: '''O "Mestre Curador" - amplifica energia e intenção. 
        Um dos cristais mais versáteis, pode ser programado para qualquer propósito.''',
        elements: [CrystalElement.spirit],
        chakras: CrystalChakra.values, // Todos os chakras
        magicalProperties: [
          'Amplificação de energia',
          'Clareza mental',
          'Proteção energética',
          'Conexão espiritual',
          'Manifestação de intenções',
        ],
        emotionalProperties: [
          'Clareza emocional',
          'Equilíbrio',
          'Foco',
          'Paz interior',
        ],
        physicalProperties: [
          'Fortalecimento do sistema imunológico (uso energético)',
          'Alívio de dores (uso energético)',
          'Melhora da concentração',
        ],
        care: CrystalCareInstructions(
          cleansingMethods: [
            CleansingMethod(method: 'Água corrente', isSafe: true),
            CleansingMethod(method: 'Sal grosso', isSafe: true),
            CleansingMethod(method: 'Defumação', isSafe: true),
            CleansingMethod(method: 'Som (sino, tigela)', isSafe: true),
            CleansingMethod(method: 'Terra', isSafe: true),
            CleansingMethod(method: 'Selenita', isSafe: true),
          ],
          chargingMethods: [
            ChargingMethod(
              method: 'Luz solar',
              isSafe: true,
              instructions: 'Deixar no sol da manhã por 2-4 horas',
            ),
            ChargingMethod(
              method: 'Luz lunar',
              isSafe: true,
              instructions: 'Deixar sob a lua cheia durante a noite',
            ),
            ChargingMethod(method: 'Cluster de quartzo', isSafe: true),
            ChargingMethod(method: 'Visualização', isSafe: true),
          ],
          storageRecommendations: [
            'Guardar separado de cristais mais macios',
            'Pode ser guardado com outros quartzos',
            'Limpar antes de guardar',
          ],
        ),
        combinationsHarmonic: [
          'Ametista - proteção espiritual',
          'Quartzo rosa - amor e cura',
          'Citrino - manifestação e prosperidade',
        ],
        combinationsAvoid: [],
        warnings: [
          'Não fazer elixir sem conhecimento adequado',
          'Não substitui tratamento médico',
          'Pode amplificar energias negativas se não limpo',
        ],
        howToUse: [
          'Meditar segurando na mão dominante',
          'Colocar sobre chakra específico',
          'Usar em grade de cristais',
          'Carregar no bolso como amuleto',
          'Colocar perto da cama para sonhos lúcidos',
        ],
        zodiacSigns: 'Todos os signos',
        planetaryCorrespondence: 'Sol, Lua',
      ),
      
      // AMETISTA
      Crystal(
        id: 'amethyst',
        name: 'Ametista',
        scientificName: 'SiO₂ (Quartzo com ferro)',
        composition: 'Dióxido de silício com traços de ferro',
        colorDescription: 'Roxo claro a roxo escuro',
        hardnessMohs: 7.0,
        origin: 'Brasil, Uruguai, Zâmbia, Madagascar',
        description: '''A "Pedra da Espiritualidade" - promove conexão espiritual, 
        intuição e proteção psíquica. Tradicionalmente usada para sobriedade e clareza mental.''',
        elements: [CrystalElement.air, CrystalElement.water],
        chakras: [CrystalChakra.thirdEye, CrystalChakra.crown],
        magicalProperties: [
          'Proteção psíquica',
          'Desenvolvimento da intuição',
          'Conexão com o divino',
          'Transmutação de energia negativa',
          'Abertura do terceiro olho',
        ],
        emotionalProperties: [
          'Calma e serenidade',
          'Alívio do estresse',
          'Superação de vícios',
          'Clareza emocional',
          'Paz interior',
        ],
        physicalProperties: [
          'Melhora da qualidade do sono',
          'Alívio de dores de cabeça (uso energético)',
          'Apoio na desintoxicação (energético)',
        ],
        care: CrystalCareInstructions(
          cleansingMethods: [
            CleansingMethod(method: 'Água corrente', isSafe: true),
            CleansingMethod(method: 'Sal grosso', isSafe: true),
            CleansingMethod(method: 'Defumação', isSafe: true),
            CleansingMethod(method: 'Som', isSafe: true),
            CleansingMethod(method: 'Lua', isSafe: true),
          ],
          chargingMethods: [
            ChargingMethod(
              method: 'Luz solar',
              isSafe: false,
              warning: 'EVITAR - pode desbotar a cor',
              instructions: 'Prefira luz lunar ou métodos alternativos',
            ),
            ChargingMethod(
              method: 'Luz lunar',
              isSafe: true,
              instructions: 'Ideal na lua cheia ou nova',
            ),
            ChargingMethod(method: 'Geodo de ametista', isSafe: true),
            ChargingMethod(method: 'Meditação', isSafe: true),
          ],
          storageRecommendations: [
            'Guardar longe da luz solar direta',
            'Pode ser guardada com outros cristais',
            'Envolver em tecido roxo aumenta a energia',
          ],
        ),
        combinationsHarmonic: [
          'Quartzo transparente - amplificação',
          'Lepidolita - calma profunda',
          'Selenita - limpeza áurica',
          'Labradorita - proteção psíquica',
        ],
        combinationsAvoid: [
          'Citrino - energias opostas (calma vs ação)',
        ],
        warnings: [
          'Pode desbotar com exposição prolongada ao sol',
          'Não substitui tratamento para dependências',
          'Algumas pessoas podem achar a energia muito forte inicialmente',
        ],
        howToUse: [
          'Sob o travesseiro para sonhos proféticos',
          'No terceiro olho durante meditação',
          'Como joia para proteção diária',
          'Em água lunar (não ingerir)',
          'No altar como ferramenta de transmutação',
        ],
        zodiacSigns: 'Peixes, Virgem, Aquário, Capricórnio',
        planetaryCorrespondence: 'Júpiter, Netuno',
      ),
      
      // OBSIDIANA
      Crystal(
        id: 'obsidian',
        name: 'Obsidiana',
        scientificName: 'Vidro vulcânico',
        composition: 'Sílica com óxidos minerais',
        colorDescription: 'Preto vítreo, às vezes com reflexos dourados ou prateados',
        hardnessMohs: 5.5,
        origin: 'México, Islândia, Japão, Equador',
        description: '''A "Pedra da Verdade" - vidro vulcânico formado por lava 
        resfriada rapidamente. Poderosa para proteção e revelação de verdades ocultas.''',
        elements: [CrystalElement.fire, CrystalElement.earth],
        chakras: [CrystalChakra.root],
        magicalProperties: [
          'Proteção forte contra negatividade',
          'Revelação de verdades ocultas',
          'Corte de cordões energéticos',
          'Aterramento profundo',
          'Escudo psíquico',
        ],
        emotionalProperties: [
          'Confronto com sombras internas',
          'Liberação de traumas',
          'Coragem para mudanças',
          'Clareza sobre ilusões',
        ],
        physicalProperties: [
          'Alívio de tensões (uso energético)',
          'Suporte na desintoxicação emocional',
        ],
        care: CrystalCareInstructions(
          cleansingMethods: [
            CleansingMethod(
              method: 'Água corrente',
              isSafe: true,
              instructions: 'Secar imediatamente para evitar manchas',
            ),
            CleansingMethod(method: 'Defumação', isSafe: true),
            CleansingMethod(method: 'Terra', isSafe: true),
            CleansingMethod(method: 'Sal grosso', isSafe: true),
          ],
          chargingMethods: [
            ChargingMethod(method: 'Luz lunar', isSafe: true),
            ChargingMethod(method: 'Terra', isSafe: true),
            ChargingMethod(
              method: 'Luz solar',
              isSafe: true,
              instructions: 'Curtos períodos apenas',
            ),
          ],
          storageRecommendations: [
            'Cuidado - pode lascar ou quebrar',
            'Guardar embrulhada em tecido',
            'Separar de cristais mais duros',
          ],
        ),
        combinationsHarmonic: [
          'Turmalina negra - proteção máxima',
          'Hematita - aterramento',
          'Quartzo fumê - transmutação',
        ],
        combinationsAvoid: [
          'Quartzo rosa - energias muito diferentes',
          'Citrino - pode criar conflito energético',
        ],
        warnings: [
          'Pode ser intensa para pessoas sensíveis',
          'Trabalha profundamente - usar com moderação inicialmente',
          'Arestas podem ser cortantes se lascada',
          'Não recomendada para crianças pequenas',
        ],
        howToUse: [
          'Esfera para adivinhação (scrying)',
          'Nos pés durante meditação para aterramento',
          'Como escudo protetor na entrada de casa',
          'Em rituais de banimento',
          'Para trabalho com sombras em terapia',
        ],
        zodiacSigns: 'Escorpião, Capricórnio',
        planetaryCorrespondence: 'Saturno, Plutão',
      ),
      
      // SELENITA
      Crystal(
        id: 'selenite',
        name: 'Selenita',
        scientificName: 'CaSO₄·2H₂O (Gesso hidratado)',
        composition: 'Sulfato de cálcio hidratado',
        colorDescription: 'Branco translúcido a transparente, brilho perolado',
        hardnessMohs: 2.0,
        origin: 'México, Marrocos, Madagascar, Brasil',
        description: '''A "Luz Líquida" - cristal de alta vibração para limpeza, 
        clareza mental e conexão com reinos superiores. Nome deriva de Selene, deusa da Lua.''',
        elements: [CrystalElement.water, CrystalElement.spirit],
        chakras: [CrystalChakra.crown, CrystalChakra.thirdEye],
        magicalProperties: [
          'Limpeza áurica instantânea',
          'Conexão com anjos e guias',
          'Clareza mental suprema',
          'Abertura de portais energéticos',
          'Carregamento de outros cristais',
        ],
        emotionalProperties: [
          'Paz profunda',
          'Serenidade',
          'Clareza emocional',
          'Dissolução de bloqueios',
        ],
        physicalProperties: [
          'Alinhamento da coluna (energético)',
          'Clareza mental',
          'Melhora da flexibilidade (energético)',
        ],
        care: CrystalCareInstructions(
          cleansingMethods: [
            CleansingMethod(
              method: 'Água',
              isSafe: false,
              warning: 'NUNCA! Selenita dissolve em água',
            ),
            CleansingMethod(method: 'Som', isSafe: true),
            CleansingMethod(method: 'Visualização', isSafe: true),
            CleansingMethod(
              method: 'Defumação',
              isSafe: true,
              instructions: 'Método ideal para selenita',
            ),
          ],
          chargingMethods: [
            ChargingMethod(
              method: 'Luz lunar',
              isSafe: true,
              instructions: 'Perfeita para selenita - conexão lunar',
            ),
            ChargingMethod(method: 'Luz solar suave', isSafe: true),
            ChargingMethod(
              method: 'Auto-carregável',
              isSafe: true,
              instructions: 'Selenita não precisa ser carregada frequentemente',
            ),
          ],
          storageRecommendations: [
            'Manter SEMPRE seca',
            'Muito macia - guardar separadamente',
            'Evitar locais úmidos',
            'Pode ser usada para limpar outros cristais',
          ],
        ),
        combinationsHarmonic: [
          'Ametista - conexão espiritual elevada',
          'Quartzo transparente - clareza amplificada',
          'Angelita - comunicação angelical',
        ],
        combinationsAvoid: [],
        warnings: [
          'NUNCA molhar - dissolve em água',
          'Muito macia - risca facilmente',
          'Fibras podem soltar - manuseie com cuidado',
          'Não fazer elixir direto',
        ],
        howToUse: [
          'Varinha para limpeza áurica',
          'Torre no ambiente para purificação',
          'Sobre outros cristais para limpá-los',
          'Na cabeceira para sonhos lúcidos',
          'Em meditação para conexão divina',
        ],
        zodiacSigns: 'Câncer, Peixes',
        planetaryCorrespondence: 'Lua',
      ),
    ];
  }

  // Avisos gerais de segurança para todos os cristais
  static const List<String> generalSafetyWarnings = [
    'Cristais NÃO substituem tratamento médico profissional',
    'Sempre pesquise antes de fazer elixires - muitos cristais são tóxicos',
    'Alguns cristais contêm metais pesados - não ingira',
    'Crianças pequenas não devem manusear cristais pequenos (risco de engolir)',
    'Selenita, halita e outros cristais solúveis NUNCA devem ir na água',
    'Pirita pode liberar enxofre - não use em elixires',
    'Malaquita e crisocola contêm cobre - tóxicas se ingeridas',
    'Cinábrio contém mercúrio - manuseie com cuidado, lave as mãos',
    'Muitos cristais desbotam no sol: ametista, quartzo rosa, citrino, água-marinha',
    'Cristais macios (selenita, calcita) riscam facilmente - guardar separados',
  ];

  // Métodos seguros universais
  static const List<String> universalSafeMethods = [
    'Defumação com sálvia, palo santo ou incenso',
    'Som de sinos, tigelas ou mantras',
    'Visualização e intenção',
    'Luz lunar (segura para todos)',
    'Reiki ou outras energias de cura',
  ];

  // Cristais que NUNCA devem ir na água
  static const List<String> waterUnsafeCrystals = [
    'Selenita - dissolve',
    'Halita (sal-gema) - dissolve',
    'Calcita - pode dissolver',
    'Celestita - pode dissolver',
    'Fluorita - pode liberar flúor',
    'Lepidolita - contém lítio',
    'Moldavita - pode fragmentar',
    'Ulexita - fibras podem soltar',
    'Pirita - pode oxidar e liberar ácido',
    'Hematita - pode enferrujar',
  ];

  // Cristais que desbotam no sol
  static const List<String> sunSensitiveCrystals = [
    'Ametista - fica clara ou amarelada',
    'Quartzo rosa - perde a cor rosa',
    'Citrino - pode clarear',
    'Água-marinha - desbota',
    'Fluorita - perde cor',
    'Celestita - desbota',
    'Kunzita - muito sensível ao sol',
    'Topázio - pode perder cor',
  ];
}

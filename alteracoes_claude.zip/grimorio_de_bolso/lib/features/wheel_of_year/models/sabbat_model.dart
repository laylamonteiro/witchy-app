import 'package:freezed_annotation/freezed_annotation.dart';

part 'sabbat_model.freezed.dart';
part 'sabbat_model.g.dart';

enum SabbatType {
  samhain('Samhain', 'Ano Novo das Bruxas'),
  yule('Yule', 'Solstício de Inverno'),
  imbolc('Imbolc', 'Festival da Luz Crescente'),
  ostara('Ostara', 'Equinócio da Primavera'),
  beltane('Beltane', 'Festival do Fogo'),
  litha('Litha', 'Solstício de Verão'),
  lughnasadh('Lughnasadh/Lammas', 'Primeira Colheita'),
  mabon('Mabon', 'Equinócio de Outono');

  final String name;
  final String subtitle;
  
  const SabbatType(this.name, this.subtitle);
}

@freezed
class Sabbat with _$Sabbat {
  const factory Sabbat({
    required SabbatType type,
    required DateTime dateNorthernHemisphere,
    required DateTime dateSouthernHemisphere,
    required String description,
    required String meaning,
    @Default([]) List<String> traditions,
    @Default([]) List<String> ritualSuggestions,
    @Default([]) List<String> foods,
    @Default([]) List<String> colors,
    @Default([]) List<String> symbols,
    @Default([]) List<String> crystals,
    @Default([]) List<String> herbs,
    String? personalNotes,
  }) = _Sabbat;

  factory Sabbat.fromJson(Map<String, dynamic> json) => _$SabbatFromJson(json);
}

// Dados dos Sabbats com correção para Hemisfério Sul
class SabbatData {
  static List<Sabbat> getSabbatsForYear(int year) {
    return [
      // SAMHAIN - Ano Novo das Bruxas
      Sabbat(
        type: SabbatType.samhain,
        dateNorthernHemisphere: DateTime(year, 10, 31),
        dateSouthernHemisphere: DateTime(year, 4, 30), // 30 de Abril/1º de Maio no Brasil
        description: 'O Ano Novo das Bruxas, quando o véu entre os mundos está mais fino',
        meaning: '''Samhain marca o fim do ano das bruxas e o início do novo ciclo. 
        É o momento de honrar os ancestrais, refletir sobre o ano que passou e 
        preparar-se para o período de introspecção. No Brasil, coincide com o 
        início do outono/inverno, período de recolhimento.''',
        traditions: [
          'Montar altar para ancestrais com fotos e oferendas',
          'Fazer jantar silencioso em honra aos que partiram',
          'Praticar adivinhação para o ano que vem',
          'Deixar vela acesa na janela para guiar espíritos',
          'Escrever carta aos ancestrais',
        ],
        ritualSuggestions: [
          'Ritual de liberação do ano velho',
          'Meditação para contato com ancestrais',
          'Leitura de tarot ou runas para o novo ano',
          'Queima segura de ervas de proteção',
          'Preparo de oferendas (água, pão, frutas)',
        ],
        foods: [
          'Abóbora e pratos com abóbora',
          'Maçãs e cidra de maçã',
          'Pães caseiros',
          'Sopas e caldos quentes',
          'Castanhas e nozes',
          'Romã',
        ],
        colors: ['Preto', 'Laranja', 'Roxo escuro', 'Dourado escuro'],
        symbols: ['Abóbora', 'Caveira', 'Caldeirão', 'Foice', 'Crisântemo'],
        crystals: ['Obsidiana', 'Ônix', 'Turmalina negra', 'Ágata'],
        herbs: ['Artemísia', 'Alecrim', 'Sálvia', 'Louro', 'Cravo'],
      ),
      
      // YULE - Solstício de Inverno
      Sabbat(
        type: SabbatType.yule,
        dateNorthernHemisphere: DateTime(year, 12, 21),
        dateSouthernHemisphere: DateTime(year, 6, 21), // 21 de Junho no Brasil
        description: 'O retorno da luz, a noite mais longa do ano',
        meaning: '''Yule celebra o renascimento do Sol após a noite mais longa. 
        No Brasil, ocorre em junho, período de festas juninas que mantêm 
        a tradição do fogo sagrado. É tempo de renovação e esperança.''',
        traditions: [
          'Acender velas para chamar o Sol',
          'Decorar com sempre-vivas e pinheiro',
          'Trocar presentes simbólicos',
          'Fazer fogueira (ou vela) para honrar o Sol',
          'Vigília da noite mais longa',
        ],
        ritualSuggestions: [
          'Ritual de renovação e renascimento',
          'Meditação com velas douradas',
          'Criar amuleto solar de proteção',
          'Banho de canela e laranja para prosperidade',
          'Escrever intenções para quando a luz retornar',
        ],
        foods: [
          'Quentão e vinho quente com especiarias',
          'Pães de mel e gengibre',
          'Frutas secas e castanhas',
          'Pratos com milho (tradição junina)',
          'Laranja e limão',
        ],
        colors: ['Vermelho', 'Verde', 'Dourado', 'Branco'],
        symbols: ['Sol', 'Roda', 'Sempre-vivas', 'Sinos', 'Visco'],
        crystals: ['Rubi', 'Granada', 'Citrino', 'Quartzo transparente'],
        herbs: ['Canela', 'Cravo', 'Gengibre', 'Pinho', 'Louro'],
      ),
      
      // IMBOLC - Festival da Luz Crescente
      Sabbat(
        type: SabbatType.imbolc,
        dateNorthernHemisphere: DateTime(year, 2, 2),
        dateSouthernHemisphere: DateTime(year, 8, 1), // 1º de Agosto no Brasil
        description: 'A promessa da primavera, festival de purificação',
        meaning: '''Imbolc marca o despertar da Terra. No Brasil, em agosto, 
        sentimos os primeiros sinais da primavera chegando. É tempo de 
        limpeza, purificação e preparação para o novo crescimento.''',
        traditions: [
          'Grande limpeza da casa (física e energética)',
          'Benção de velas para o ano',
          'Plantar sementes em vasos',
          'Fazer boneca de Brígida com palha',
          'Deixar pano na janela para benção de Brígida',
        ],
        ritualSuggestions: [
          'Ritual de purificação com água e sal',
          'Consagração de velas brancas',
          'Meditação de renovação',
          'Limpeza de ferramentas mágicas',
          'Banho de leite com mel (ou substitutos vegetais)',
        ],
        foods: [
          'Produtos lácteos (ou alternativas vegetais)',
          'Pães com sementes',
          'Chás de ervas',
          'Mel',
          'Alimentos brancos',
        ],
        colors: ['Branco', 'Rosa claro', 'Amarelo claro', 'Verde claro'],
        symbols: ['Vela', 'Flor de neve', 'Ovelha', 'Chama', 'Poço'],
        crystals: ['Ametista', 'Quartzo rosa', 'Selenita', 'Pedra da lua'],
        herbs: ['Camomila', 'Lavanda', 'Angélica', 'Urtiga', 'Violeta'],
      ),
      
      // OSTARA - Equinócio da Primavera
      Sabbat(
        type: SabbatType.ostara,
        dateNorthernHemisphere: DateTime(year, 3, 21),
        dateSouthernHemisphere: DateTime(year, 9, 21), // 21 de Setembro no Brasil
        description: 'Equilíbrio entre luz e escuridão, renovação',
        meaning: '''Ostara celebra o equilíbrio perfeito e o início da primavera. 
        No Brasil, em setembro, a natureza desperta plenamente. 
        É tempo de novos começos e crescimento.''',
        traditions: [
          'Pintar ovos com símbolos mágicos',
          'Plantar jardim de ervas',
          'Fazer oferenda de sementes para pássaros',
          'Criar altar com flores da estação',
          'Caminhar na natureza ao amanhecer',
        ],
        ritualSuggestions: [
          'Ritual de equilíbrio e harmonia',
          'Benção de sementes para plantio',
          'Meditação do equilíbrio',
          'Criar talismã de fertilidade e crescimento',
          'Limpeza com água de flores',
        ],
        foods: [
          'Ovos preparados de várias formas',
          'Saladas com brotos e folhas verdes',
          'Pães com ervas frescas',
          'Mel e produtos apícolas',
          'Sementes e castanhas',
        ],
        colors: ['Verde', 'Amarelo', 'Rosa', 'Lilás'],
        symbols: ['Ovo', 'Coelho', 'Flores', 'Borboleta', 'Arco-íris'],
        crystals: ['Água-marinha', 'Aventurina', 'Quartzo verde', 'Jaspe'],
        herbs: ['Narciso', 'Violeta', 'Jasmim', 'Rosa', 'Açafrão'],
      ),
      
      // BELTANE - Festival do Fogo
      Sabbat(
        type: SabbatType.beltane,
        dateNorthernHemisphere: DateTime(year, 5, 1),
        dateSouthernHemisphere: DateTime(year, 10, 31), // 31 de Outubro/1º Novembro no Brasil
        description: 'Celebração da fertilidade e união',
        meaning: '''Beltane celebra a vida em sua plenitude. No Brasil, 
        coincide com o Dia de Finados, mas energeticamente é sobre 
        celebrar a vida, o amor e a fertilidade criativa.''',
        traditions: [
          'Dançar em volta da fogueira (ou velas)',
          'Fazer coroa de flores',
          'Pular fogueira para purificação e sorte',
          'Colher orvalho ao amanhecer',
          'Fazer fitas coloridas para desejos',
        ],
        ritualSuggestions: [
          'Ritual de atração e magnetismo',
          'Consagração de talismãs de amor',
          'Handfasting simbólico',
          'Banho de pétalas de rosa',
          'Criar sachê de ervas do amor',
        ],
        foods: [
          'Morangos e frutas vermelhas',
          'Vinho ou suco de uva',
          'Pães com flores comestíveis',
          'Saladas coloridas',
          'Bolos de mel',
        ],
        colors: ['Vermelho', 'Verde vibrante', 'Dourado', 'Rosa'],
        symbols: ['Fogo', 'Flores', 'Fitas', 'Chifres', 'Coroa de flores'],
        crystals: ['Esmeralda', 'Quartzo rosa', 'Carnélia', 'Malaquita'],
        herbs: ['Rosa', 'Espinheiro', 'Lavanda', 'Hortelã', 'Tomilho'],
      ),
      
      // LITHA - Solstício de Verão
      Sabbat(
        type: SabbatType.litha,
        dateNorthernHemisphere: DateTime(year, 6, 21),
        dateSouthernHemisphere: DateTime(year, 12, 21), // 21 de Dezembro no Brasil
        description: 'O auge do poder solar, dia mais longo',
        meaning: '''Litha marca o pico do poder do Sol. No Brasil, em dezembro, 
        coincide com as festas de fim de ano. É momento de celebração, 
        gratidão e reconhecimento do poder pessoal.''',
        traditions: [
          'Assistir ao nascer do sol',
          'Fazer coroa de girassóis ou flores amarelas',
          'Colher ervas mágicas ao meio-dia',
          'Criar água solar',
          'Festa ao ar livre',
        ],
        ritualSuggestions: [
          'Ritual de poder pessoal e sucesso',
          'Carregar cristais ao sol do meio-dia',
          'Criar amuleto solar',
          'Banho de sol (com proteção!)',
          'Queimar papel com medos (com segurança)',
        ],
        foods: [
          'Frutas frescas da estação',
          'Saladas coloridas',
          'Sucos naturais',
          'Girassol (sementes)',
          'Pratos com limão',
        ],
        colors: ['Amarelo', 'Laranja', 'Dourado', 'Vermelho'],
        symbols: ['Sol', 'Girassol', 'Fogo', 'Roda solar', 'Abelha'],
        crystals: ['Âmbar', 'Citrino', 'Olho de tigre', 'Topázio'],
        herbs: ['Hipérico', 'Calêndula', 'Camomila', 'Girassol', 'Verbena'],
      ),
      
      // LUGHNASADH/LAMMAS - Primeira Colheita
      Sabbat(
        type: SabbatType.lughnasadh,
        dateNorthernHemisphere: DateTime(year, 8, 1),
        dateSouthernHemisphere: DateTime(year, 2, 2), // 2 de Fevereiro no Brasil
        description: 'Festival da primeira colheita, gratidão',
        meaning: '''Lughnasadh celebra a primeira colheita. No Brasil, em fevereiro, 
        após o verão abundante, é tempo de agradecer e compartilhar. 
        Reconhecemos o sacrifício necessário para a abundância.''',
        traditions: [
          'Fazer pão caseiro',
          'Compartilhar refeição em comunidade',
          'Fazer boneco de milho ou trigo',
          'Jogos e competições amigáveis',
          'Trançar espigas',
        ],
        ritualSuggestions: [
          'Ritual de gratidão e abundância',
          'Oferenda de pão e grãos',
          'Meditação sobre sacrifício e recompensa',
          'Criar talismã de prosperidade',
          'Benção dos grãos',
        ],
        foods: [
          'Pães variados',
          'Milho em todas as formas',
          'Cerveja ou bebidas fermentadas',
          'Frutas da estação',
          'Grãos e cereais',
        ],
        colors: ['Dourado', 'Marrom', 'Laranja', 'Verde escuro'],
        symbols: ['Espiga', 'Foice', 'Pão', 'Milho', 'Cesta'],
        crystals: ['Cornalina', 'Ágata', 'Jaspe vermelho', 'Peridoto'],
        herbs: ['Trigo', 'Milho', 'Cevada', 'Menta', 'Meadowsweet'],
      ),
      
      // MABON - Equinócio de Outono
      Sabbat(
        type: SabbatType.mabon,
        dateNorthernHemisphere: DateTime(year, 9, 21),
        dateSouthernHemisphere: DateTime(year, 3, 21), // 21 de Março no Brasil
        description: 'Segunda colheita, equilíbrio e gratidão',
        meaning: '''Mabon marca o segundo equilíbrio do ano e a segunda colheita. 
        No Brasil, em março, preparamos para o outono. É tempo de 
        gratidão, equilíbrio e preparação para o recolhimento.''',
        traditions: [
          'Fazer lista de gratidão',
          'Decorar com folhas e pinhas',
          'Preparar conservas e geleias',
          'Compartilhar colheita com necessitados',
          'Caminhada para coletar folhas e sementes',
        ],
        ritualSuggestions: [
          'Ritual de equilíbrio luz/sombra',
          'Meditação de gratidão',
          'Liberação do que não serve mais',
          'Criar altar de gratidão',
          'Preparar elixir de maçã',
        ],
        foods: [
          'Maçãs e tortas de maçã',
          'Uvas e vinho',
          'Abóboras e raízes',
          'Nozes e castanhas',
          'Cogumelos',
        ],
        colors: ['Laranja', 'Vermelho', 'Marrom', 'Dourado escuro'],
        symbols: ['Cornucópia', 'Maçã', 'Folhas', 'Balança', 'Uva'],
        crystals: ['Âmbar', 'Topázio', 'Citrino', 'Ágata'],
        herbs: ['Sálvia', 'Calêndula', 'Rosa mosqueta', 'Maçã', 'Hera'],
      ),
    ];
  }

  // Notas importantes sobre adaptação ao Hemisfério Sul
  static const Map<String, String> hemisphereAdaptationNotes = {
    'geral': '''No Hemisfério Sul, os Sabbats ocorrem em datas opostas ao 
    Hemisfério Norte. Isso reflete as estações invertidas: quando é 
    inverno no Norte, é verão no Sul.''',
    
    'energia': '''As energias dos Sabbats devem ser adaptadas ao ciclo natural 
    local. Por exemplo, não faz sentido celebrar colheita em março no 
    Norte quando no Sul estamos no outono.''',
    
    'tradições_locais': '''No Brasil, muitas datas coincidem com festas locais:
    - Yule (junho) coincide com Festas Juninas
    - Litha (dezembro) com festas de fim de ano
    - Beltane (outubro/novembro) com Finados
    Integre as tradições locais à sua prática!''',
    
    'natureza': '''Observe a natureza ao seu redor. Os Sabbats são sobre 
    conexão com os ciclos naturais. Se as folhas estão caindo, é 
    outono, independente do que diz o calendário do Norte.''',
  };

  // Avisos de segurança para rituais
  static const List<String> safetyWarnings = [
    'Sempre pratique segurança com fogo - nunca deixe velas sem supervisão',
    'Ao fazer fogueiras, respeite regulamentos locais e tenha água por perto',
    'Verifique alergias antes de usar ervas em banhos ou incensos',
    'Não ingira ervas sem conhecimento adequado',
    'Proteja-se do sol durante rituais ao ar livre',
    'Respeite a natureza - não arranque plantas protegidas',
    'Em rituais em grupo, estabeleça limites e consentimento',
  ];
}

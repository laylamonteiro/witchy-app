import 'package:freezed_annotation/freezed_annotation.dart';

part 'moon_phase_model.freezed.dart';
part 'moon_phase_model.g.dart';

enum MoonPhaseType {
  newMoon('Lua Nova', 'nova'),
  waxingCrescent('Lua Crescente', 'crescente'),
  firstQuarter('Quarto Crescente', 'quarto_crescente'),
  waxingGibbous('Gibosa Crescente', 'gibosa_crescente'),
  fullMoon('Lua Cheia', 'cheia'),
  waningGibbous('Gibosa Minguante', 'gibosa_minguante'),
  lastQuarter('Quarto Minguante', 'quarto_minguante'),
  waningCrescent('Lua Minguante', 'minguante');

  final String displayName;
  final String value;
  
  const MoonPhaseType(this.displayName, this.value);
}

@freezed
class MoonPhase with _$MoonPhase {
  const factory MoonPhase({
    required MoonPhaseType type,
    required DateTime date,
    required double illumination,
    required String zodiacSign,
    @Default([]) List<MagicalCorrespondence> correspondences,
    @Default([]) List<String> ritualSuggestions,
  }) = _MoonPhase;

  factory MoonPhase.fromJson(Map<String, dynamic> json) =>
      _$MoonPhaseFromJson(json);
}

@freezed
class MagicalCorrespondence with _$MagicalCorrespondence {
  const factory MagicalCorrespondence({
    required String category,
    required String description,
    @Default([]) List<String> keywords,
    @Default([]) List<String> warnings,
  }) = _MagicalCorrespondence;

  factory MagicalCorrespondence.fromJson(Map<String, dynamic> json) =>
      _$MagicalCorrespondenceFromJson(json);
}

// Dados estáticos sobre correspondências lunares
class MoonPhaseData {
  static Map<MoonPhaseType, List<MagicalCorrespondence>> correspondences = {
    MoonPhaseType.newMoon: [
      MagicalCorrespondence(
        category: 'Intenções',
        description: 'Momento ideal para novos começos e plantio de sementes energéticas',
        keywords: ['novos projetos', 'intenções', 'planejamento', 'introspecção'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Tipos de Magia',
        description: 'Trabalhos de banimento, limpeza profunda e renovação',
        keywords: ['banimento', 'limpeza', 'proteção', 'meditação'],
        warnings: ['Evite trabalhos que requeiram muita energia externa'],
      ),
      MagicalCorrespondence(
        category: 'Cristais',
        description: 'Obsidiana, turmalina negra, labradorita',
        keywords: ['proteção', 'limpeza', 'renovação'],
        warnings: ['Limpe os cristais antes do uso'],
      ),
      MagicalCorrespondence(
        category: 'Ervas',
        description: 'Sálvia, alecrim, mirra',
        keywords: ['purificação', 'proteção', 'clareza'],
        warnings: ['Não queime ervas em ambientes fechados sem ventilação'],
      ),
    ],
    
    MoonPhaseType.waxingCrescent: [
      MagicalCorrespondence(
        category: 'Intenções',
        description: 'Crescimento, atração e desenvolvimento de projetos',
        keywords: ['crescimento', 'atração', 'desenvolvimento', 'coragem'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Tipos de Magia',
        description: 'Feitiços de prosperidade, amor e crescimento pessoal',
        keywords: ['prosperidade', 'amor', 'abundância', 'saúde'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Cristais',
        description: 'Citrino, pirita, aventurina verde',
        keywords: ['prosperidade', 'crescimento', 'sorte'],
        warnings: ['Citrino pode desbotar ao sol'],
      ),
      MagicalCorrespondence(
        category: 'Ervas',
        description: 'Manjericão, canela, gengibre',
        keywords: ['prosperidade', 'atração', 'energia'],
        warnings: ['Canela pode causar irritação na pele sensível'],
      ),
    ],
    
    MoonPhaseType.fullMoon: [
      MagicalCorrespondence(
        category: 'Intenções',
        description: 'Pico de poder mágico, manifestação e celebração',
        keywords: ['manifestação', 'gratidão', 'poder', 'celebração'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Tipos de Magia',
        description: 'Todos os tipos de magia, especialmente cura e adivinhação',
        keywords: ['cura', 'adivinhação', 'manifestação', 'consagração'],
        warnings: ['Energias intensas podem afetar pessoas sensíveis'],
      ),
      MagicalCorrespondence(
        category: 'Cristais',
        description: 'Quartzo transparente, selenita, pedra da lua',
        keywords: ['amplificação', 'intuição', 'poder'],
        warnings: ['Selenita dissolve em água'],
      ),
      MagicalCorrespondence(
        category: 'Ervas',
        description: 'Artemísia, jasmim, rosa branca',
        keywords: ['poder psíquico', 'amor', 'proteção'],
        warnings: ['Artemísia não deve ser ingerida por grávidas'],
      ),
      MagicalCorrespondence(
        category: 'Água Lunar',
        description: 'Ideal para criar água lunar deixando água em recipiente de vidro sob a luz da lua',
        keywords: ['consagração', 'limpeza', 'energização'],
        warnings: ['Use apenas água potável se for ingerir'],
      ),
    ],
    
    MoonPhaseType.waningCrescent: [
      MagicalCorrespondence(
        category: 'Intenções',
        description: 'Liberação, cura e finalização de ciclos',
        keywords: ['liberação', 'cura', 'perdão', 'limpeza'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Tipos de Magia',
        description: 'Banimento de hábitos negativos, cura emocional',
        keywords: ['banimento', 'cura', 'liberação', 'perdão'],
        warnings: [],
      ),
      MagicalCorrespondence(
        category: 'Cristais',
        description: 'Ametista, lepidolita, quartzo fumê',
        keywords: ['transmutação', 'calma', 'liberação'],
        warnings: ['Ametista pode desbotar com exposição ao sol'],
      ),
      MagicalCorrespondence(
        category: 'Ervas',
        description: 'Lavanda, eucalipto, hortelã',
        keywords: ['limpeza', 'cura', 'paz'],
        warnings: ['Eucalipto é tóxico para pets'],
      ),
    ],
  };

  static List<String> getRitualSuggestions(MoonPhaseType phase) {
    switch (phase) {
      case MoonPhaseType.newMoon:
        return [
          'Escreva suas intenções para o novo ciclo lunar',
          'Faça uma limpeza energética profunda em seu espaço',
          'Medite sobre o que deseja manifestar',
          'Crie um quadro de visão para o mês',
          'Banho de ervas para renovação (alecrim e sal grosso)',
        ];
      
      case MoonPhaseType.waxingCrescent:
      case MoonPhaseType.firstQuarter:
      case MoonPhaseType.waxingGibbous:
        return [
          'Acenda velas verdes ou douradas para prosperidade',
          'Plante sementes ou cuide de plantas',
          'Faça um pote de abundância com moedas e canela',
          'Pratique afirmações positivas diariamente',
          'Carregue um cristal de citrino para atração',
        ];
      
      case MoonPhaseType.fullMoon:
        return [
          'Prepare água lunar para consagração',
          'Faça um ritual de gratidão listando conquistas',
          'Carregue seus cristais sob a luz da lua',
          'Pratique adivinhação (tarot, runas, pêndulo)',
          'Realize um ritual de manifestação com velas',
          'Faça um banho energético com pétalas de rosa',
        ];
      
      case MoonPhaseType.waningGibbous:
      case MoonPhaseType.lastQuarter:
      case MoonPhaseType.waningCrescent:
        return [
          'Escreva e queime (com segurança) o que deseja liberar',
          'Faça uma limpeza física e energética da casa',
          'Tome um banho de sal grosso para purificação',
          'Pratique meditação de perdão e liberação',
          'Use cristais de ametista para transmutação',
        ];
    }
  }

  // Avisos de segurança importantes
  static const List<String> generalSafetyWarnings = [
    'Sempre pratique segurança com fogo - use velas em suportes apropriados',
    'Verifique toxicidade de ervas antes de ingerir ou usar na pele',
    'Mantenha cristais e ervas longe de crianças e pets',
    'Respeite alergias e sensibilidades pessoais',
    'Nunca deixe velas acesas sem supervisão',
    'Selenita e outros cristais solúveis não devem ir na água',
    'Ametista, citrino e quartzo rosa podem desbotar no sol',
    'Artemísia, arruda e outras ervas são contraindicadas para grávidas',
    'Sempre tenha ventilação adequada ao queimar incensos ou ervas',
  ];

  // Adaptação para Hemisfério Sul
  static const Map<String, String> hemisphereNotes = {
    'geral': 'No Hemisfério Sul, as energias sazonais são invertidas',
    'lua_crescente': 'Associada ao Outono/Inverno no Brasil - energia de preparação',
    'lua_cheia': 'Plenitude adaptada ao ciclo local de plantio e colheita',
    'lua_minguante': 'Associada à Primavera/Verão no Brasil - limpeza para renovação',
  };
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:grimorio_de_bolso/core/theme/app_theme.dart';
import 'package:grimorio_de_bolso/core/router/app_router.dart';
import 'package:grimorio_de_bolso/core/database/database_service.dart';
import 'package:grimorio_de_bolso/core/notifications/notification_service.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:timezone/data/latest.dart' as tz;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Configurar orientação (apenas portrait)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  // Configurar localização para pt_BR
  await initializeDateFormatting('pt_BR', null);
  Intl.defaultLocale = 'pt_BR';
  
  // Inicializar timezone
  tz.initializeTimeZones();
  
  // Inicializar banco de dados
  await DatabaseService.instance.database;
  
  // Inicializar notificações
  await NotificationService.instance.initialize();
  
  // Configurar status bar
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.background,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );
  
  runApp(
    const ProviderScope(
      child: GrimorioDeBolsoApp(),
    ),
  );
}

class GrimorioDeBolsoApp extends ConsumerWidget {
  const GrimorioDeBolsoApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    
    return MaterialApp.router(
      title: 'Grimório de Bolso',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      routerConfig: router,
      locale: const Locale('pt', 'BR'),
      supportedLocales: const [
        Locale('pt', 'BR'),
      ],
      builder: (context, child) {
        // Adicionar efeitos globais de partículas mágicas
        return Stack(
          children: [
            child!,
            // Overlay de partículas mágicas será adicionado aqui
            const IgnorePointer(
              child: MagicParticlesOverlay(),
            ),
          ],
        );
      },
    );
  }
}

// Widget de partículas mágicas (glitter effect)
class MagicParticlesOverlay extends StatefulWidget {
  const MagicParticlesOverlay({super.key});

  @override
  State<MagicParticlesOverlay> createState() => _MagicParticlesOverlayState();
}

class _MagicParticlesOverlayState extends State<MagicParticlesOverlay>
    with TickerProviderStateMixin {
  final List<MagicParticle> particles = [];
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    // Criar partículas iniciais
    for (int i = 0; i < 15; i++) {
      particles.add(MagicParticle.random());
    }

    _controller.addListener(() {
      setState(() {
        // Atualizar posição das partículas
        for (var particle in particles) {
          particle.update();
        }
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: MagicParticlesPainter(particles),
      size: MediaQuery.of(context).size,
    );
  }
}

class MagicParticle {
  double x;
  double y;
  double size;
  double opacity;
  double speed;
  Color color;
  double fadeSpeed;

  MagicParticle({
    required this.x,
    required this.y,
    required this.size,
    required this.opacity,
    required this.speed,
    required this.color,
    required this.fadeSpeed,
  });

  factory MagicParticle.random() {
    final random = DateTime.now().millisecondsSinceEpoch;
    final colors = [
      AppColors.lilac,
      AppColors.starYellow,
      AppColors.mint.withOpacity(0.5),
    ];
    
    return MagicParticle(
      x: (random % 1000) / 1000,
      y: (random % 1000) / 1000,
      size: 1 + (random % 3).toDouble(),
      opacity: 0.1 + (random % 50) / 100,
      speed: 0.001 + (random % 10) / 10000,
      color: colors[random % colors.length],
      fadeSpeed: 0.002 + (random % 5) / 1000,
    );
  }

  void update() {
    y -= speed;
    opacity -= fadeSpeed;
    
    // Resetar partícula quando sair da tela ou ficar invisível
    if (y < -0.1 || opacity <= 0) {
      y = 1.1;
      opacity = 0.3 + (DateTime.now().millisecondsSinceEpoch % 40) / 100;
    }
  }
}

class MagicParticlesPainter extends CustomPainter {
  final List<MagicParticle> particles;

  MagicParticlesPainter(this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    for (var particle in particles) {
      final paint = Paint()
        ..color = particle.color.withOpacity(particle.opacity)
        ..style = PaintingStyle.fill;
      
      canvas.drawCircle(
        Offset(particle.x * size.width, particle.y * size.height),
        particle.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

# 📚 Grimório de Bolso - App de Bruxaria Moderna

## 🌙 Sobre o App

**Grimório de Bolso** é um aplicativo mobile pensado para bruxas e bruxos iniciantes, especialmente no Brasil, que desejam organizar sua prática mágica de forma moderna e acessível.

### 🎨 Identidade Visual
- **Estilo**: Whimsigoth / Pastel Goth
- **Mood**: Magia aconchegante, não terror
- **Elementos**: Lua, estrelas, cristais, gatos, velas, pentagramas

## ⚠️ Correções Importantes sobre Conceitos de Bruxaria

### 1. **Hemisfério Sul - Roda do Ano** ✅
**CORREÇÃO NECESSÁRIA**: Os Sabbats devem ser ajustados para o Hemisfério Sul:

#### Calendário Correto para Brasil:
- **Samhain**: 30 de Abril/1º de Maio (não 31 de Outubro)
- **Yule (Solstício de Inverno)**: ~21 de Junho (não 21 de Dezembro)
- **Imbolc**: 1º de Agosto (não 1º de Fevereiro)
- **Ostara (Equinócio de Primavera)**: ~21 de Setembro (não 21 de Março)
- **Beltane**: 31 de Outubro/1º de Novembro (não 1º de Maio)
- **Litha (Solstício de Verão)**: ~21 de Dezembro (não 21 de Junho)
- **Lughnasadh/Lammas**: 1º de Fevereiro (não 1º de Agosto)
- **Mabon (Equinócio de Outono)**: ~21 de Março (não 21 de Setembro)

### 2. **Fases da Lua e Magia** ✅
**CORRETO** com ajustes:
- **Lua Nova**: Novos começos, plantio de intenções, banimento
- **Lua Crescente**: Atração, crescimento, prosperidade
- **Lua Cheia**: Poder máximo, manifestação, gratidão, celebração
- **Lua Minguante**: Limpeza, banimento, liberação, cura

### 3. **Cristais - Limpeza e Energização** ⚠️
**ADIÇÕES IMPORTANTES**:
- Nem todos os cristais podem ir na água (ex: selenita dissolve)
- Nem todos podem ir no sol (ex: ametista desbota)
- Métodos seguros universais: luz lunar, defumação, terra, som

### 4. **Elementos e Correspondências** ✅
**CORRETO** com complementos:
- **Terra**: Norte (Brasil), estabilidade, prosperidade
- **Água**: Oeste, emoções, intuição
- **Fogo**: Sul (Brasil), paixão, transformação
- **Ar**: Leste, comunicação, pensamento

### 5. **Ervas e Segurança** ⚠️
**AVISOS IMPORTANTES**:
- Sempre verificar toxicidade antes de ingerir
- Cuidado com pets (muitas ervas são tóxicas para animais)
- Respeitar dosagens e alergias
- Preferir uso externo quando em dúvida

## 🚀 Stack Técnica

- **Frontend**: Flutter 3.x
- **Local Storage**: SQLite com sqflite
- **State Management**: Riverpod 2.0
- **Arquitetura**: Clean Architecture + MVVM
- **Backend (Fase 2)**: Supabase ou AWS Amplify
- **IA (Fase 2)**: OpenAI API via proxy backend

## 📱 Módulos Principais

### Fase 1 - MVP Local (Atual)
1. **Tempo Mágico**: Calendário lunar e Roda do Ano (corrigido para Hemisfério Sul)
2. **Grimório Digital**: CRUD de feitiços com fases lunares
3. **Diários**: Sonhos, Desejos e Prática
4. **Enciclopédia**: Cristais e Cores (com avisos de segurança)
5. **Sigilos**: Gerador com Roda Alfabética

### Fase 2 - Cloud + IA
6. **Autenticação**: Login/cadastro
7. **Sincronização**: Backup na nuvem
8. **IA Assistente**: Criação inteligente de feitiços

### Fase 3 - Premium
9. **Astrologia**: Mapa astral e perfil mágico
10. **Jornadas**: Programas guiados de 21 dias
11. **Gamificação**: Badges e conquistas

## 🎯 Diferenciais

- **Adaptado ao Brasil**: Datas, hemisfério sul, cultura local
- **Segurança em Primeiro Lugar**: Avisos sobre uso de ervas, cristais e fogo
- **Sem Dogmatismo**: Respeita diferentes tradições
- **Científico e Mágico**: Une conhecimento tradicional com segurança moderna
- **Inclusivo**: Linguagem neutra disponível

## 📚 Fontes Verificadas

As informações do app foram verificadas com base em:
- Theodosia Corinth: Guias de Auto Cuidado, Cristais e Astrologia para Bruxas
- Jason Mankey et al.: O Grimório Completo das Bruxas
- Lindsay Squire: Série completa de Bruxaria (Terra, Verde, Tarô, Astrologia)
- Scott Cunningham: Enciclopédia de Cristais e Ervas Mágicas
- Raymond Buckland: Livro Completo de Bruxaria

## 🔒 Avisos Legais e de Segurança

- Este app é para fins educacionais e espirituais
- Não substitui aconselhamento médico ou psicológico
- Sempre priorize segurança ao trabalhar com fogo, ervas ou cristais
- Respeite as leis locais sobre práticas espirituais
- Informações sobre ervas não devem ser usadas para consumo sem orientação profissional

---

Desenvolvido com 🌙 e ✨ para a comunidade bruxa brasileira

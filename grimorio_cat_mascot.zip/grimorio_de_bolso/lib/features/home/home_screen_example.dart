import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:grimorio_de_bolso/widgets/draggable_cat_mascot.dart';

// Exemplo de como usar o mascote gatinho na tela principal

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  // Controle de visibilidade do mascote (pode ser um provider)
  bool _showMascot = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B0A16), // Fundo roxo escuro
      body: Stack(
        children: [
          // Conteúdo principal da tela
          SafeArea(
            child: CustomScrollView(
              slivers: [
                // AppBar customizada
                SliverAppBar(
                  floating: true,
                  backgroundColor: Colors.transparent,
                  title: Text(
                    'Grimório de Bolso',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  actions: [
                    // Botão para toggle do mascote
                    IconButton(
                      icon: Icon(
                        _showMascot ? Icons.pets : Icons.pets_outlined,
                        color: const Color(0xFFC9A7FF),
                      ),
                      onPressed: () {
                        setState(() {
                          _showMascot = !_showMascot;
                        });
                      },
                    ),
                  ],
                ),
                
                // Conteúdo da tela
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 1,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    delegate: SliverChildListDelegate([
                      _buildFeatureCard(
                        context,
                        icon: '🌙',
                        title: 'Calendário Lunar',
                        subtitle: 'Fases e rituais',
                      ),
                      _buildFeatureCard(
                        context,
                        icon: '📖',
                        title: 'Grimório',
                        subtitle: 'Seus feitiços',
                      ),
                      _buildFeatureCard(
                        context,
                        icon: '💎',
                        title: 'Cristais',
                        subtitle: 'Enciclopédia',
                      ),
                      _buildFeatureCard(
                        context,
                        icon: '✨',
                        title: 'Sigilos',
                        subtitle: 'Criar símbolos',
                      ),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          
          // Mascote gatinho arrastável
          if (_showMascot)
            const DraggableBlackCatMascot(),
          
          // Dica inicial (aparece só na primeira vez)
          if (_showMascot)
            Positioned(
              top: 150,
              left: 20,
              child: _buildTooltip(),
            ),
        ],
      ),
    );
  }

  Widget _buildFeatureCard(
    BuildContext context, {
    required String icon,
    required String title,
    required String subtitle,
  }) {
    return GestureDetector(
      onTap: () {
        // Navegação para a feature
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF171425), // Surface color
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: const Color(0xFF26213A),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFC9A7FF).withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              icon,
              style: const TextStyle(fontSize: 40),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Color(0xFFC9A7FF),
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            Text(
              subtitle,
              style: TextStyle(
                color: const Color(0xFFB7B2D6).withOpacity(0.8),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTooltip() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(seconds: 1),
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF171425),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFFC9A7FF),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFC9A7FF).withOpacity(0.3),
                  blurRadius: 12,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.touch_app,
                  color: Color(0xFFFFE8A3),
                  size: 20,
                ),
                const SizedBox(width: 8),
                const Text(
                  'Toque e arraste o gatinho!',
                  style: TextStyle(
                    color: Color(0xFFF6F4FF),
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// Provider para controlar preferências do mascote
final mascotPreferencesProvider = StateProvider<MascotPreferences>((ref) {
  return MascotPreferences(
    isVisible: true,
    position: const Offset(50, 100),
    favoriteSpot: null,
  );
});

class MascotPreferences {
  final bool isVisible;
  final Offset position;
  final Offset? favoriteSpot;

  MascotPreferences({
    required this.isVisible,
    required this.position,
    this.favoriteSpot,
  });

  MascotPreferences copyWith({
    bool? isVisible,
    Offset? position,
    Offset? favoriteSpot,
  }) {
    return MascotPreferences(
      isVisible: isVisible ?? this.isVisible,
      position: position ?? this.position,
      favoriteSpot: favoriteSpot ?? this.favoriteSpot,
    );
  }
}

// Configurações do mascote que podem ser salvas
class MascotSettings extends StatelessWidget {
  const MascotSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF171425),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            '🐈‍⬛ Configurações do Mascote',
            style: TextStyle(
              color: Color(0xFFC9A7FF),
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          
          // Nome do gatinho
          TextFormField(
            initialValue: 'Luna',
            decoration: const InputDecoration(
              labelText: 'Nome do gatinho',
              prefixIcon: Icon(Icons.edit, color: Color(0xFFC9A7FF)),
            ),
          ),
          const SizedBox(height: 12),
          
          // Personalidade
          const Text(
            'Personalidade',
            style: TextStyle(color: Color(0xFFB7B2D6)),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              _buildPersonalityChip('Brincalhão', true),
              _buildPersonalityChip('Dorminhoco', false),
              _buildPersonalityChip('Carinhoso', true),
              _buildPersonalityChip('Curioso', false),
            ],
          ),
          const SizedBox(height: 16),
          
          // Frequência de interação
          const Text(
            'Frequência de aparição',
            style: TextStyle(color: Color(0xFFB7B2D6)),
          ),
          Slider(
            value: 0.7,
            onChanged: (value) {},
            activeColor: const Color(0xFFC9A7FF),
            inactiveColor: const Color(0xFF26213A),
          ),
          
          const SizedBox(height: 16),
          
          // Efeitos especiais
          SwitchListTile(
            title: const Text(
              'Partículas mágicas',
              style: TextStyle(color: Color(0xFFF6F4FF)),
            ),
            subtitle: const Text(
              'Brilhos ao tocar',
              style: TextStyle(color: Color(0xFFB7B2D6), fontSize: 12),
            ),
            value: true,
            onChanged: (value) {},
            activeColor: const Color(0xFFC9A7FF),
          ),
          
          SwitchListTile(
            title: const Text(
              'Sons',
              style: TextStyle(color: Color(0xFFF6F4FF)),
            ),
            subtitle: const Text(
              'Miados e ronrons',
              style: TextStyle(color: Color(0xFFB7B2D6), fontSize: 12),
            ),
            value: false,
            onChanged: (value) {},
            activeColor: const Color(0xFFC9A7FF),
          ),
        ],
      ),
    );
  }

  Widget _buildPersonalityChip(String label, bool selected) {
    return Chip(
      label: Text(
        label,
        style: TextStyle(
          color: selected ? const Color(0xFF2B2143) : const Color(0xFFF6F4FF),
          fontSize: 12,
        ),
      ),
      backgroundColor: selected ? const Color(0xFFC9A7FF) : const Color(0xFF26213A),
      side: BorderSide(
        color: selected ? const Color(0xFFC9A7FF) : const Color(0xFF26213A),
      ),
    );
  }
}

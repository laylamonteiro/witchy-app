import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:grimorio_de_bolso/widgets/draggable_black_cat_mascot.dart';
import 'package:grimorio_de_bolso/core/theme/app_theme.dart';

/// Exemplo de tela principal com o mascote gatinho preto
/// 
/// Demonstra como integrar o mascote arrastável sem bloquear
/// as interações com o resto da interface
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  // Estado para mensagens do gatinho
  String _catMessage = '';
  bool _showMessage = false;

  // Frases mágicas do gatinho
  final List<String> _catPhrases = [
    'Miau! A lua está linda hoje! 🌙',
    'Purr... sinto energias mágicas por perto ✨',
    'Os cristais estão vibrando alto hoje! 💎',
    'Hora de fazer um feitiço de proteção? 🛡️',
    'Miau! Não esqueça de limpar seus cristais! 🔮',
    'As estrelas sussurram segredos... ⭐',
    'Purr purr... que tal um ritual de gratidão? 🕯️',
    'Sinto cheiro de lavanda no ar... 🌿',
    'A Deusa está sorrindo para você! 🌛',
    'Miau! Hoje é dia de lua crescente! 🌒',
  ];

  void _onCatTap() {
    // Escolher uma frase aleatória
    final phrase = _catPhrases[
      DateTime.now().millisecondsSinceEpoch % _catPhrases.length
    ];
    
    setState(() {
      _catMessage = phrase;
      _showMessage = true;
    });
    
    // Esconder mensagem após 3 segundos
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _showMessage = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Conteúdo principal da tela
          SafeArea(
            child: CustomScrollView(
              slivers: [
                // AppBar customizada
                SliverAppBar(
                  expandedHeight: 120,
                  floating: true,
                  backgroundColor: AppColors.background,
                  flexibleSpace: FlexibleSpaceBar(
                    title: Text(
                      'Grimório de Bolso',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    centerTitle: true,
                  ),
                ),
                
                // Cards de exemplo
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _buildMoonPhaseCard(context),
                      const SizedBox(height: 16),
                      _buildQuickAccessCard(context),
                      const SizedBox(height: 16),
                      _buildDailyTipCard(context),
                      const SizedBox(height: 100), // Espaço extra no final
                    ]),
                  ),
                ),
              ],
            ),
          ),
          
          // Mensagem flutuante do gatinho
          AnimatedPositioned(
            duration: const Duration(milliseconds: 300),
            top: _showMessage ? 100 : -100,
            left: 20,
            right: 20,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 300),
              opacity: _showMessage ? 1.0 : 0.0,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppColors.lilac.withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.lilac.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.starYellow,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.starYellow.withOpacity(0.5),
                            blurRadius: 4,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _catMessage,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          // MASCOTE GATINHO ARRASTÁVEL
          // Fica por cima de tudo mas não bloqueia interações
          DraggableBlackCatMascot(
            initialX: MediaQuery.of(context).size.width - 80,
            initialY: MediaQuery.of(context).size.height - 200,
            size: 50,
            onTap: _onCatTap,
          ),
        ],
      ),
      
      // Bottom Navigation
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          boxShadow: [
            BoxShadow(
              color: AppColors.lilac.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: 0,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: 'Início',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.menu_book_outlined),
              activeIcon: Icon(Icons.menu_book),
              label: 'Grimório',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_month_outlined),
              activeIcon: Icon(Icons.calendar_month),
              label: 'Calendário',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.auto_awesome_outlined),
              activeIcon: Icon(Icons.auto_awesome),
              label: 'Cristais',
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildMoonPhaseCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.nightlight_round,
                  color: AppColors.lilac,
                ),
                const SizedBox(width: 8),
                Text(
                  'Fase Lunar Atual',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              '🌒 Lua Crescente',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              'Momento ideal para feitiços de atração e crescimento',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildQuickAccessCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Acesso Rápido',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _buildQuickActionChip(
                  context,
                  icon: Icons.auto_fix_high,
                  label: 'Novo Feitiço',
                  color: AppColors.lilac,
                ),
                _buildQuickActionChip(
                  context,
                  icon: Icons.book,
                  label: 'Diário',
                  color: AppColors.pinkWitch,
                ),
                _buildQuickActionChip(
                  context,
                  icon: Icons.stars,
                  label: 'Sigilo',
                  color: AppColors.mint,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildDailyTipCard(BuildContext context) {
    return Card(
      color: AppColors.surface,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.surface,
              AppColors.lilac.withOpacity(0.1),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    color: AppColors.starYellow,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Dica do Dia',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                '✨ Selenita nunca deve ser molhada! Ela dissolve em água. '
                'Use defumação ou som para limpá-la.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildQuickActionChip(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return ActionChip(
      avatar: Icon(icon, size: 18, color: color),
      label: Text(label),
      backgroundColor: color.withOpacity(0.1),
      side: BorderSide(color: color.withOpacity(0.3)),
      onPressed: () {
        // Ação do chip
      },
    );
  }
}

// Exemplo de como adicionar o gatinho em qualquer tela:
// 
// Stack(
//   children: [
//     // Seu conteúdo normal aqui
//     YourContent(),
//     
//     // Adicione o gatinho por último para ficar por cima
//     DraggableBlackCatMascot(
//       initialX: 300,  // Posição inicial X
//       initialY: 100,  // Posição inicial Y
//       size: 50,       // Tamanho do gatinho
//       onTap: () {
//         // Ação quando clicar no gatinho
//         print('Miau! 🐱');
//       },
//     ),
//   ],
// )

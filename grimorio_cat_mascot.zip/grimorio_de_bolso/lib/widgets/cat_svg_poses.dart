// Arquivo com todas as poses do gatinho em SVG
// Baseado no black_cat_mascot.svg original, com variações

String getCatSvgForPose(CatPose pose, bool isBlinking) {
  switch (pose) {
    case CatPose.sitting:
      return _getSittingCat(isBlinking);
    case CatPose.walking:
      return _getWalkingCat(isBlinking);
    case CatPose.lying:
      return _getLyingCat(isBlinking);
    case CatPose.sleeping:
      return _getSleepingCat();
    case CatPose.alert:
      return _getAlertCat(isBlinking);
    case CatPose.grooming:
      return _getGroomingCat();
    case CatPose.playing:
      return _getPlayingCat(isBlinking);
  }
}

// Gatinho sentado (pose padrão)
String _getSittingCat(bool isBlinking) {
  final eyes = isBlinking 
    ? '''
      <!-- Olhos fechados -->
      <path d="M 18 20 Q 20 19 22 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 42 20 Q 44 19 46 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
    '''
    : '''
      <!-- Olhos abertos -->
      <circle cx="20" cy="20" r="3" fill="#C9A7FF"/>
      <circle cx="44" cy="20" r="3" fill="#C9A7FF"/>
      <circle cx="21" cy="20" r="1.5" fill="#FFE8A3"/>
      <circle cx="45" cy="20" r="1.5" fill="#FFE8A3"/>
    ''';

  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="18" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo -->
      <path d="M 45 40 Q 52 35 54 25 Q 55 20 52 18" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="none"/>
      
      <!-- Corpo -->
      <ellipse cx="32" cy="40" rx="16" ry="18" fill="#0B0A16"/>
      
      <!-- Cabeça -->
      <circle cx="32" cy="22" r="14" fill="#0B0A16"/>
      
      <!-- Orelhas -->
      <path d="M 20 15 L 18 8 L 24 12 Z" fill="#0B0A16"/>
      <path d="M 44 15 L 46 8 L 40 12 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 20.5 12 L 19.5 9 L 22 11 Z" fill="#F1A7C5"/>
      <path d="M 43.5 12 L 44.5 9 L 42 11 Z" fill="#F1A7C5"/>
      
      $eyes
      
      <!-- Focinho -->
      <path d="M 32 24 L 30 26 L 32 27 L 34 26 Z" fill="#F1A7C5"/>
      
      <!-- Boca -->
      <path d="M 32 27 Q 29 29 26 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <path d="M 32 27 Q 35 29 38 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      
      <!-- Bigodes -->
      <line x1="10" y1="22" x2="18" y2="21" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="10" y1="25" x2="18" y2="24" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="46" y1="21" x2="54" y2="22" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="46" y1="24" x2="54" y2="25" stroke="#B7B2D6" stroke-width="0.5"/>
      
      <!-- Patas -->
      <ellipse cx="24" cy="52" rx="5" ry="7" fill="#0B0A16"/>
      <ellipse cx="40" cy="52" rx="5" ry="7" fill="#0B0A16"/>
      
      <!-- Almofadinhas -->
      <ellipse cx="24" cy="55" rx="2" ry="1.5" fill="#F1A7C5"/>
      <ellipse cx="40" cy="55" rx="2" ry="1.5" fill="#F1A7C5"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="32" cy="32" rx="12" ry="2" fill="#C9A7FF"/>
      <circle cx="32" cy="33" r="2" fill="#FFE8A3"/>
    </svg>
  ''';
}

// Gatinho andando
String _getWalkingCat(bool isBlinking) {
  final eyes = isBlinking 
    ? '''
      <path d="M 16 20 Q 18 19 20 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 40 20 Q 42 19 44 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
    '''
    : '''
      <circle cx="18" cy="20" r="3" fill="#C9A7FF"/>
      <circle cx="42" cy="20" r="3" fill="#C9A7FF"/>
      <circle cx="19" cy="20" r="1.5" fill="#FFE8A3"/>
      <circle cx="43" cy="20" r="1.5" fill="#FFE8A3"/>
    ''';

  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="20" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo levantado -->
      <path d="M 48 38 Q 54 30 56 22 Q 57 18 55 15" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="none"/>
      
      <!-- Corpo inclinado para frente -->
      <ellipse cx="34" cy="40" rx="18" ry="14" fill="#0B0A16" 
               transform="rotate(-10 34 40)"/>
      
      <!-- Cabeça -->
      <circle cx="28" cy="22" r="14" fill="#0B0A16"/>
      
      <!-- Orelhas alertas -->
      <path d="M 16 15 L 13 8 L 20 11 Z" fill="#0B0A16"/>
      <path d="M 40 15 L 43 8 L 36 11 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 16.5 12 L 14.5 9 L 18 11 Z" fill="#F1A7C5"/>
      <path d="M 39.5 12 L 41.5 9 L 38 11 Z" fill="#F1A7C5"/>
      
      $eyes
      
      <!-- Focinho -->
      <path d="M 28 24 L 26 26 L 28 27 L 30 26 Z" fill="#F1A7C5"/>
      
      <!-- Boca determinada -->
      <path d="M 28 27 Q 25 28 22 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <path d="M 28 27 Q 31 28 34 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      
      <!-- Bigodes para frente -->
      <line x1="6" y1="22" x2="14" y2="21" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="6" y1="25" x2="14" y2="24" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="42" y1="21" x2="50" y2="21" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="42" y1="24" x2="50" y2="24" stroke="#B7B2D6" stroke-width="0.5"/>
      
      <!-- Patas em movimento -->
      <ellipse cx="20" cy="52" rx="5" ry="7" fill="#0B0A16" 
               transform="rotate(-15 20 52)"/>
      <ellipse cx="32" cy="54" rx="5" ry="7" fill="#0B0A16"/>
      <ellipse cx="44" cy="52" rx="5" ry="7" fill="#0B0A16" 
               transform="rotate(15 44 52)"/>
      <ellipse cx="36" cy="54" rx="5" ry="7" fill="#0B0A16"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="28" cy="32" rx="11" ry="2" fill="#C9A7FF"/>
      <circle cx="28" cy="33" r="2" fill="#FFE8A3"/>
    </svg>
  ''';
}

// Gatinho deitado
String _getLyingCat(bool isBlinking) {
  final eyes = isBlinking 
    ? '''
      <path d="M 22 18 Q 24 17 26 18" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 38 18 Q 40 17 42 18" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
    '''
    : '''
      <ellipse cx="24" cy="18" rx="3" ry="2" fill="#C9A7FF"/>
      <ellipse cx="40" cy="18" rx="3" ry="2" fill="#C9A7FF"/>
      <circle cx="25" cy="18" r="1" fill="#FFE8A3"/>
      <circle cx="41" cy="18" r="1" fill="#FFE8A3"/>
    ''';

  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="24" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo enrolado -->
      <path d="M 50 45 Q 58 42 59 35 Q 59 28 55 26 Q 48 26 46 32" 
            stroke="#0B0A16" stroke-width="7" stroke-linecap="round" fill="none"/>
      
      <!-- Corpo deitado -->
      <ellipse cx="32" cy="45" rx="24" ry="12" fill="#0B0A16"/>
      
      <!-- Cabeça apoiada -->
      <ellipse cx="32" cy="22" rx="14" ry="12" fill="#0B0A16"/>
      
      <!-- Orelhas relaxadas -->
      <path d="M 20 16 L 17 9 L 24 13 Z" fill="#0B0A16"/>
      <path d="M 44 16 L 47 9 L 40 13 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 20 13 L 18.5 10 L 22 12 Z" fill="#F1A7C5"/>
      <path d="M 44 13 L 45.5 10 L 42 12 Z" fill="#F1A7C5"/>
      
      $eyes
      
      <!-- Focinho -->
      <path d="M 32 22 L 30 24 L 32 25 L 34 24 Z" fill="#F1A7C5"/>
      
      <!-- Boca relaxada -->
      <path d="M 32 25 Q 29 26 27 25" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <path d="M 32 25 Q 35 26 37 25" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      
      <!-- Bigodes -->
      <line x1="12" y1="20" x2="20" y2="19" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="12" y1="23" x2="20" y2="22" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="44" y1="19" x2="52" y2="20" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="44" y1="22" x2="52" y2="23" stroke="#B7B2D6" stroke-width="0.5"/>
      
      <!-- Patas dobradas -->
      <ellipse cx="18" cy="50" rx="6" ry="4" fill="#0B0A16"/>
      <ellipse cx="46" cy="50" rx="6" ry="4" fill="#0B0A16"/>
      
      <!-- Almofadinhas visíveis -->
      <ellipse cx="16" cy="51" rx="2" ry="1" fill="#F1A7C5"/>
      <ellipse cx="20" cy="51" rx="2" ry="1" fill="#F1A7C5"/>
      <ellipse cx="44" cy="51" rx="2" ry="1" fill="#F1A7C5"/>
      <ellipse cx="48" cy="51" rx="2" ry="1" fill="#F1A7C5"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="32" cy="30" rx="10" ry="2" fill="#C9A7FF"/>
      <circle cx="32" cy="31" r="2" fill="#FFE8A3"/>
    </svg>
  ''';
}

// Gatinho dormindo
String _getSleepingCat() {
  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="22" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo cobrindo o rosto -->
      <path d="M 48 42 Q 56 38 58 30 Q 58 22 52 18 Q 44 16 38 20 Q 32 24 30 30" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="#0B0A16"/>
      
      <!-- Corpo enrolado -->
      <ellipse cx="32" cy="42" rx="20" ry="14" fill="#0B0A16"/>
      
      <!-- Cabeça escondida -->
      <ellipse cx="28" cy="26" rx="12" ry="10" fill="#0B0A16"/>
      
      <!-- Orelhas dobradas -->
      <path d="M 18 22 L 16 16 L 22 20 Z" fill="#0B0A16"/>
      <path d="M 38 22 L 40 16 L 34 20 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 18.5 20 L 17 17 L 20 19 Z" fill="#F1A7C5"/>
      <path d="M 37.5 20 L 39 17 L 36 19 Z" fill="#F1A7C5"/>
      
      <!-- Olhos fechados (linhas) -->
      <path d="M 22 24 Q 24 23 26 24" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 30 24 Q 32 23 34 24" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      
      <!-- ZZZ -->
      <text x="45" y="15" fill="#C9A7FF" opacity="0.6" font-size="8" font-family="Arial">
        Z
      </text>
      <text x="50" y="10" fill="#C9A7FF" opacity="0.4" font-size="6" font-family="Arial">
        z
      </text>
      <text x="53" y="6" fill="#C9A7FF" opacity="0.2" font-size="4" font-family="Arial">
        z
      </text>
      
      <!-- Patas escondidas sob o corpo -->
      <ellipse cx="20" cy="48" rx="5" ry="3" fill="#0B0A16"/>
      <ellipse cx="44" cy="48" rx="5" ry="3" fill="#0B0A16"/>
      
      <!-- Coleira mágica parcialmente visível -->
      <path d="M 20 32 Q 28 30 36 32" stroke="#C9A7FF" stroke-width="2" fill="none"/>
      <circle cx="28" cy="31" r="1.5" fill="#FFE8A3"/>
    </svg>
  ''';
}

// Gatinho alerta/acordado
String _getAlertCat(bool isBlinking) {
  final eyes = isBlinking 
    ? '''
      <path d="M 18 20 Q 20 19 22 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 42 20 Q 44 19 46 20" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
    '''
    : '''
      <!-- Olhos grandes e alertas -->
      <circle cx="20" cy="20" r="4" fill="#C9A7FF"/>
      <circle cx="44" cy="20" r="4" fill="#C9A7FF"/>
      <circle cx="21" cy="19" r="2" fill="#FFE8A3"/>
      <circle cx="45" cy="19" r="2" fill="#FFE8A3"/>
      <!-- Pupilas dilatadas -->
      <circle cx="21" cy="20" r="1" fill="#0B0A16"/>
      <circle cx="45" cy="20" r="1" fill="#0B0A16"/>
    ''';

  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="16" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo ereto -->
      <path d="M 42 40 Q 44 30 45 20 Q 45 15 44 12" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="none"/>
      <!-- Ponta do rabo eriçada -->
      <circle cx="44" cy="10" r="5" fill="#0B0A16"/>
      
      <!-- Corpo tenso -->
      <ellipse cx="32" cy="40" rx="14" ry="16" fill="#0B0A16"/>
      
      <!-- Cabeça erguida -->
      <circle cx="32" cy="22" r="14" fill="#0B0A16"/>
      
      <!-- Orelhas muito alertas -->
      <path d="M 18 15 L 15 6 L 23 10 Z" fill="#0B0A16"/>
      <path d="M 46 15 L 49 6 L 41 10 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 18.5 11 L 16.5 8 L 21 10 Z" fill="#F1A7C5"/>
      <path d="M 45.5 11 L 47.5 8 L 43 10 Z" fill="#F1A7C5"/>
      
      $eyes
      
      <!-- Focinho -->
      <path d="M 32 24 L 30 26 L 32 27 L 34 26 Z" fill="#F1A7C5"/>
      
      <!-- Boca séria -->
      <path d="M 32 27 Q 29 28 26 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <path d="M 32 27 Q 35 28 38 27" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      
      <!-- Bigodes eriçados -->
      <line x1="8" y1="20" x2="18" y2="19" stroke="#B7B2D6" stroke-width="0.7"/>
      <line x1="8" y1="24" x2="18" y2="23" stroke="#B7B2D6" stroke-width="0.7"/>
      <line x1="46" y1="19" x2="56" y2="20" stroke="#B7B2D6" stroke-width="0.7"/>
      <line x1="46" y1="23" x2="56" y2="24" stroke="#B7B2D6" stroke-width="0.7"/>
      
      <!-- Patas firmemente plantadas -->
      <ellipse cx="26" cy="52" rx="4" ry="7" fill="#0B0A16"/>
      <ellipse cx="38" cy="52" rx="4" ry="7" fill="#0B0A16"/>
      
      <!-- Garras levemente expostas -->
      <path d="M 24 56 L 24 58" stroke="#F6F4FF" stroke-width="0.5"/>
      <path d="M 26 56 L 26 58" stroke="#F6F4FF" stroke-width="0.5"/>
      <path d="M 28 56 L 28 58" stroke="#F6F4FF" stroke-width="0.5"/>
      <path d="M 36 56 L 36 58" stroke="#F6F4FF" stroke-width="0.5"/>
      <path d="M 38 56 L 38 58" stroke="#F6F4FF" stroke-width="0.5"/>
      <path d="M 40 56 L 40 58" stroke="#F6F4FF" stroke-width="0.5"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="32" cy="32" rx="12" ry="2" fill="#C9A7FF"/>
      <circle cx="32" cy="33" r="2" fill="#FFE8A3"/>
      <!-- Sininho tilintando -->
      <circle cx="32" cy="33" r="2.5" stroke="#FFE8A3" stroke-width="0.5" fill="none" opacity="0.5"/>
    </svg>
  ''';
}

// Gatinho se limpando
String _getGroomingCat() {
  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="18" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo enrolado ao lado -->
      <path d="M 45 42 Q 52 40 54 34 Q 54 28 50 26" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="none"/>
      
      <!-- Corpo -->
      <ellipse cx="32" cy="42" rx="16" ry="16" fill="#0B0A16"/>
      
      <!-- Cabeça inclinada -->
      <ellipse cx="30" cy="24" rx="13" ry="14" fill="#0B0A16" 
               transform="rotate(-20 30 24)"/>
      
      <!-- Orelhas -->
      <path d="M 18 18 L 15 11 L 22 14 Z" fill="#0B0A16"/>
      <path d="M 40 16 L 43 9 L 36 12 Z" fill="#0B0A16"/>
      
      <!-- Interior das orelhas -->
      <path d="M 18.5 14 L 16.5 12 L 20 13 Z" fill="#F1A7C5"/>
      <path d="M 39.5 12 L 41.5 10 L 38 11 Z" fill="#F1A7C5"/>
      
      <!-- Olhos semi-fechados -->
      <path d="M 20 22 Q 22 21 24 22" stroke="#C9A7FF" stroke-width="2" fill="none"/>
      <path d="M 36 20 Q 38 19 40 20" stroke="#C9A7FF" stroke-width="2" fill="none"/>
      
      <!-- Focinho -->
      <path d="M 28 26 L 26 28 L 28 29 L 30 28 Z" fill="#F1A7C5"/>
      
      <!-- Língua lambendo a pata -->
      <ellipse cx="24" cy="30" rx="3" ry="2" fill="#F1A7C5"/>
      
      <!-- Pata levantada sendo lambida -->
      <ellipse cx="22" cy="32" rx="6" ry="4" fill="#0B0A16" 
               transform="rotate(-30 22 32)"/>
      <!-- Almofadinha da pata -->
      <ellipse cx="20" cy="32" rx="2" ry="1.5" fill="#F1A7C5"/>
      
      <!-- Outra pata no chão -->
      <ellipse cx="40" cy="52" rx="5" ry="7" fill="#0B0A16"/>
      
      <!-- Patas traseiras -->
      <ellipse cx="26" cy="52" rx="5" ry="6" fill="#0B0A16"/>
      <ellipse cx="38" cy="52" rx="5" ry="6" fill="#0B0A16"/>
      
      <!-- Bigodes -->
      <line x1="10" y1="24" x2="18" y2="23" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="10" y1="27" x2="18" y2="26" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="42" y1="22" x2="50" y2="23" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="42" y1="25" x2="50" y2="26" stroke="#B7B2D6" stroke-width="0.5"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="30" cy="34" rx="11" ry="2" fill="#C9A7FF" 
               transform="rotate(-20 30 34)"/>
      <circle cx="30" cy="35" r="2" fill="#FFE8A3"/>
    </svg>
  ''';
}

// Gatinho brincando
String _getPlayingCat(bool isBlinking) {
  final eyes = isBlinking 
    ? '''
      <path d="M 20 18 Q 22 17 24 18" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
      <path d="M 40 18 Q 42 17 44 18" stroke="#C9A7FF" stroke-width="1.5" fill="none"/>
    '''
    : '''
      <!-- Olhos excitados -->
      <circle cx="22" cy="18" r="3.5" fill="#C9A7FF"/>
      <circle cx="42" cy="18" r="3.5" fill="#C9A7FF"/>
      <circle cx="23" cy="17" r="2" fill="#FFE8A3"/>
      <circle cx="43" cy="17" r="2" fill="#FFE8A3"/>
    ''';

  return '''
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
      <!-- Sombra -->
      <ellipse cx="32" cy="58" rx="20" ry="4" fill="#C9A7FF" opacity="0.2"/>
      
      <!-- Rabo balançando -->
      <path d="M 40 38 Q 48 32 52 24 Q 54 18 50 15" 
            stroke="#0B0A16" stroke-width="8" stroke-linecap="round" fill="none"/>
      <!-- Movimento do rabo -->
      <path d="M 48 20 Q 46 18 44 20" stroke="#C9A7FF" stroke-width="1" fill="none" opacity="0.5"/>
      
      <!-- Corpo em posição de pulo -->
      <ellipse cx="32" cy="38" rx="15" ry="18" fill="#0B0A16" 
               transform="rotate(10 32 38)"/>
      
      <!-- Cabeça -->
      <circle cx="32" cy="20" r="13" fill="#0B0A16"/>
      
      <!-- Orelhas para trás (concentração) -->
      <path d="M 20 14 L 17 7 L 24 10 Z" fill="#0B0A16" 
            transform="rotate(-10 20 14)"/>
      <path d="M 44 14 L 47 7 L 40 10 Z" fill="#0B0A16" 
            transform="rotate(10 44 14)"/>
      
      <!-- Interior das orelhas -->
      <path d="M 20 11 L 18 8 L 22 10 Z" fill="#F1A7C5"/>
      <path d="M 44 11 L 46 8 L 42 10 Z" fill="#F1A7C5"/>
      
      $eyes
      
      <!-- Focinho -->
      <path d="M 32 22 L 30 24 L 32 25 L 34 24 Z" fill="#F1A7C5"/>
      
      <!-- Boca aberta (excitação) -->
      <path d="M 32 25 Q 28 27 26 25" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <path d="M 32 25 Q 36 27 38 25" stroke="#F1A7C5" stroke-width="1" fill="none"/>
      <circle cx="32" cy="26" r="1" fill="#F1A7C5" opacity="0.5"/>
      
      <!-- Patas dianteiras estendidas (pegando algo) -->
      <ellipse cx="24" cy="46" rx="5" ry="8" fill="#0B0A16" 
               transform="rotate(-25 24 46)"/>
      <ellipse cx="40" cy="46" rx="5" ry="8" fill="#0B0A16" 
               transform="rotate(25 40 46)"/>
      
      <!-- Garras expostas -->
      <path d="M 20 50 L 18 52" stroke="#F6F4FF" stroke-width="0.7"/>
      <path d="M 22 50 L 20 52" stroke="#F6F4FF" stroke-width="0.7"/>
      <path d="M 44 50 L 46 52" stroke="#F6F4FF" stroke-width="0.7"/>
      <path d="M 42 50 L 44 52" stroke="#F6F4FF" stroke-width="0.7"/>
      
      <!-- Patas traseiras impulsionando -->
      <ellipse cx="28" cy="52" rx="6" ry="5" fill="#0B0A16"/>
      <ellipse cx="36" cy="52" rx="6" ry="5" fill="#0B0A16"/>
      
      <!-- Bigodes agitados -->
      <line x1="10" y1="18" x2="20" y2="17" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="10" y1="22" x2="20" y2="21" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="44" y1="17" x2="54" y2="18" stroke="#B7B2D6" stroke-width="0.5"/>
      <line x1="44" y1="21" x2="54" y2="22" stroke="#B7B2D6" stroke-width="0.5"/>
      
      <!-- Coleira mágica -->
      <ellipse cx="32" cy="30" rx="11" ry="2" fill="#C9A7FF"/>
      <circle cx="32" cy="31" r="2" fill="#FFE8A3"/>
      
      <!-- Bola de lã ou luz mágica (brinquedo) -->
      <circle cx="50" cy="54" r="4" fill="#C9A7FF" opacity="0.3"/>
      <circle cx="50" cy="54" r="2" fill="#FFE8A3" opacity="0.6"/>
    </svg>
  ''';
}

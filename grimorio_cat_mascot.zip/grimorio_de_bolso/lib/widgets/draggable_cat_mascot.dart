import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:math' as math;
import 'dart:async';

class DraggableBlackCatMascot extends StatefulWidget {
  const DraggableBlackCatMascot({super.key});

  @override
  State<DraggableBlackCatMascot> createState() => _DraggableBlackCatMascotState();
}

class _DraggableBlackCatMascotState extends State<DraggableBlackCatMascot>
    with TickerProviderStateMixin {
  // Posição do gatinho
  Offset _position = const Offset(50, 100);
  
  // Estado do gatinho
  CatPose _currentPose = CatPose.sitting;
  bool _isDragging = false;
  bool _isBlinking = false;
  
  // Animações
  late AnimationController _floatingController;
  late AnimationController _tailController;
  late AnimationController _sparkleController;
  late Animation<double> _floatingAnimation;
  late Animation<double> _tailAnimation;
  
  // Partículas mágicas
  final List<MagicParticle> _particles = [];
  Timer? _particleTimer;
  
  // Rastro de movimento
  final List<TrailPoint> _trail = [];
  Timer? _trailCleanupTimer;

  @override
  void initState() {
    super.initState();
    
    // Animação de flutuação suave
    _floatingController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);
    
    _floatingAnimation = Tween<double>(
      begin: 0,
      end: 8,
    ).animate(CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeInOut,
    ));
    
    // Animação do rabo
    _tailController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    
    _tailAnimation = Tween<double>(
      begin: -0.1,
      end: 0.1,
    ).animate(CurvedAnimation(
      parent: _tailController,
      curve: Curves.easeInOut,
    ));
    
    // Controlador de partículas
    _sparkleController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    )..addListener(() {
      setState(() {
        _updateParticles();
      });
    });
    
    // Piscar aleatoriamente
    _startRandomBlinking();
    
    // Limpar rastro periodicamente
    _trailCleanupTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      _cleanupTrail();
    });
  }

  @override
  void dispose() {
    _floatingController.dispose();
    _tailController.dispose();
    _sparkleController.dispose();
    _particleTimer?.cancel();
    _trailCleanupTimer?.cancel();
    super.dispose();
  }

  void _startRandomBlinking() {
    Timer.periodic(Duration(seconds: 3 + math.Random().nextInt(5)), (_) {
      if (mounted && !_isDragging) {
        setState(() {
          _isBlinking = true;
        });
        Timer(const Duration(milliseconds: 150), () {
          if (mounted) {
            setState(() {
              _isBlinking = false;
            });
          }
        });
      }
    });
  }

  void _onPanStart(DragStartDetails details) {
    setState(() {
      _isDragging = true;
      _changePose(CatPose.alert);
    });
    
    // Criar explosão de partículas ao tocar
    _createParticleBurst(details.globalPosition);
    
    // Iniciar geração contínua de partículas
    _particleTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      if (_isDragging) {
        _addParticle(_position + const Offset(32, 32));
      }
    });
    
    _sparkleController.repeat();
  }

  void _onPanUpdate(DragUpdateDetails details) {
    setState(() {
      _position += details.delta;
      
      // Adicionar ponto ao rastro
      _trail.add(TrailPoint(
        position: _position + const Offset(32, 32),
        timestamp: DateTime.now(),
      ));
      
      // Limitar tamanho do rastro
      if (_trail.length > 20) {
        _trail.removeAt(0);
      }
    });
  }

  void _onPanEnd(DragEndDetails details) {
    setState(() {
      _isDragging = false;
      _pickRandomRestPose();
    });
    
    _particleTimer?.cancel();
    _sparkleController.stop();
    
    // Criar explosão final
    _createParticleBurst(_position + const Offset(32, 32));
  }

  void _onTap() {
    // Mudar pose ao tocar
    _pickRandomPose();
    
    // Criar pequena explosão de partículas
    _createParticleBurst(_position + const Offset(32, 32), count: 5);
  }

  void _changePose(CatPose newPose) {
    setState(() {
      _currentPose = newPose;
    });
  }

  void _pickRandomPose() {
    final poses = CatPose.values.where((p) => p != CatPose.alert).toList();
    final randomPose = poses[math.Random().nextInt(poses.length)];
    _changePose(randomPose);
  }

  void _pickRandomRestPose() {
    final restPoses = [
      CatPose.sitting,
      CatPose.lying,
      CatPose.sleeping,
      CatPose.grooming,
    ];
    final randomPose = restPoses[math.Random().nextInt(restPoses.length)];
    _changePose(randomPose);
  }

  void _createParticleBurst(Offset position, {int count = 8}) {
    for (int i = 0; i < count; i++) {
      final angle = (i / count) * 2 * math.pi;
      _particles.add(MagicParticle(
        position: position,
        velocity: Offset(
          math.cos(angle) * 2,
          math.sin(angle) * 2 - 1,
        ),
        color: i % 2 == 0 
          ? const Color(0xFFFFE8A3) // Amarelo estrela
          : const Color(0xFFC9A7FF), // Lilás
        size: 3 + math.Random().nextDouble() * 3,
        lifespan: 1.0,
      ));
    }
  }

  void _addParticle(Offset position) {
    _particles.add(MagicParticle(
      position: position,
      velocity: Offset(
        (math.Random().nextDouble() - 0.5) * 2,
        -math.Random().nextDouble() * 3,
      ),
      color: math.Random().nextBool()
        ? const Color(0xFFFFE8A3)
        : const Color(0xFFC9A7FF),
      size: 2 + math.Random().nextDouble() * 2,
      lifespan: 1.0,
    ));
  }

  void _updateParticles() {
    _particles.removeWhere((particle) {
      particle.update();
      return particle.lifespan <= 0;
    });
  }

  void _cleanupTrail() {
    final now = DateTime.now();
    setState(() {
      _trail.removeWhere((point) {
        return now.difference(point.timestamp).inMilliseconds > 500;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Rastro mágico
        if (_isDragging)
          ..._trail.asMap().entries.map((entry) {
            final index = entry.key;
            final point = entry.value;
            final opacity = (index / _trail.length) * 0.3;
            
            return Positioned(
              left: point.position.dx - 2,
              top: point.position.dy - 2,
              child: Container(
                width: 4,
                height: 4,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFC9A7FF).withOpacity(opacity),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFC9A7FF).withOpacity(opacity),
                      blurRadius: 8,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            );
          }),
        
        // Partículas mágicas
        ..._particles.map((particle) => Positioned(
          left: particle.position.dx - particle.size / 2,
          top: particle.position.dy - particle.size / 2,
          child: Container(
            width: particle.size,
            height: particle.size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: particle.color.withOpacity(particle.lifespan),
              boxShadow: [
                BoxShadow(
                  color: particle.color.withOpacity(particle.lifespan * 0.5),
                  blurRadius: particle.size,
                  spreadRadius: particle.size / 2,
                ),
              ],
            ),
          ),
        )),
        
        // Gatinho
        AnimatedPositioned(
          duration: _isDragging ? Duration.zero : const Duration(milliseconds: 100),
          left: _position.dx,
          top: _position.dy,
          child: GestureDetector(
            onPanStart: _onPanStart,
            onPanUpdate: _onPanUpdate,
            onPanEnd: _onPanEnd,
            onTap: _onTap,
            child: AnimatedBuilder(
              animation: _floatingAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _isDragging ? 0 : _floatingAnimation.value),
                  child: AnimatedScale(
                    scale: _isDragging ? 1.1 : 1.0,
                    duration: const Duration(milliseconds: 200),
                    child: Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFC9A7FF).withOpacity(
                              _isDragging ? 0.4 : 0.2
                            ),
                            blurRadius: _isDragging ? 12 : 8,
                            spreadRadius: _isDragging ? 6 : 3,
                          ),
                        ],
                      ),
                      child: _buildCatSvg(),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCatSvg() {
    // Aqui você deve usar seu SVG existente ou os novos que criaremos
    return SvgPicture.string(
      getCatSvgForPose(_currentPose, _isBlinking),
      width: 64,
      height: 64,
    );
  }
}

// Enum para as poses do gatinho
enum CatPose {
  sitting,    // Sentado
  walking,    // Andando
  lying,      // Deitado
  sleeping,   // Dormindo
  alert,      // Alerta/acordado
  grooming,   // Se limpando
  playing,    // Brincando
}

// Classe para partículas mágicas
class MagicParticle {
  Offset position;
  Offset velocity;
  Color color;
  double size;
  double lifespan;
  
  MagicParticle({
    required this.position,
    required this.velocity,
    required this.color,
    required this.size,
    required this.lifespan,
  });
  
  void update() {
    position += velocity;
    velocity = velocity * 0.98; // Fricção
    velocity = velocity + const Offset(0, 0.1); // Gravidade
    lifespan -= 0.02;
  }
}

// Classe para pontos do rastro
class TrailPoint {
  final Offset position;
  final DateTime timestamp;
  
  TrailPoint({
    required this.position,
    required this.timestamp,
  });
}
